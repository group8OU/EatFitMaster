﻿Public Module Meals
    'Public meal drawing objects
    Public Fruitbox, Fruittext
    Public Proteinbox, Proteintext
    Public Grainbox, Graintext
    Public Vegetablebox, Vegetabletext
    Public Drinkbox, Drinktext
    'selection methods
    Public Sub selectfruit()
        Randomize()
        Dim fruitchoice As Integer = Math.Ceiling(Rnd() * 12)
        Select Case True
            Case fruitchoice = 1
                loadapple()
            Case fruitchoice = 2
                loadbanana()
            Case fruitchoice = 3
                loadorange()
            Case fruitchoice = 4
                loadstrawberry()
            Case fruitchoice = 5
                loadgrapes()
            Case fruitchoice = 6
                loadpapaya()
            Case fruitchoice = 7
                loadpear()
            Case fruitchoice = 8
                loadraspberry()
            Case fruitchoice = 9
                loadcherries()
            Case fruitchoice = 10
                loadblueberries()
            Case fruitchoice = 11
                loadpineapple()
            Case fruitchoice = 12
                loadavocado()
            Case Else
                MsgBox("Fruit error: " & fruitchoice)
                frmSnack.Close()
        End Select
    End Sub
    'reset objects
    Public Sub clearobjects()
        Fruitbox = Nothing
        Fruittext = Nothing
        Proteinbox = Nothing
        Proteintext = Nothing
        Grainbox = Nothing
        Grainbox = Nothing
        Vegetabletext = Nothing
        Vegetabletext = Nothing
        Drinkbox = Nothing
        Drinktext = Nothing
    End Sub
    'Fruit load methods
    Public Sub loadapple()
        Fruitbox = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Meals" & "\apple.jpg")
        Fruittext = "Apple"
    End Sub
    Public Sub loadbanana()
        Fruitbox = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Meals" & "\banana.jpg")
        Fruittext = "Banana"
    End Sub
    Public Sub loadorange()
        Fruitbox = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Meals" & "\orange.jpg")
        Fruittext = "Orange"
    End Sub
    Public Sub loadstrawberry()
        Fruitbox = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Meals" & "\strawberry.jpg")
        Fruittext = "Strawberry"
    End Sub
    Public Sub loadgrapes()
        Fruitbox = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Meals" & "\grapes.jpg")
        Fruittext = "Grapes"
    End Sub
    Public Sub loadpapaya()
        Fruitbox = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Meals" & "\papaya.jpg")
        Fruittext = "Papaya"
    End Sub
    Public Sub loadpear()
        Fruitbox = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Meals" & "\pear.jpg")
        Fruittext = "Pear"
    End Sub
    Public Sub loadraspberry()
        Fruitbox = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Meals" & "\raspberry.jpg")
        Fruittext = "Raspberry"
    End Sub
    Public Sub loadcherries()
        Fruitbox = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Meals" & "\cherries.jpg")
        Fruittext = "Cherries"
    End Sub
    Public Sub loadblueberries()
        Fruitbox = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Meals" & "\blueberries.jpg")
        Fruittext = "Blueberries"
    End Sub
    Public Sub loadpineapple()
        Fruitbox = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Meals" & "\pineapple.png")
        Fruittext = "Pineapple"
    End Sub
    Public Sub loadavocado()
        Fruitbox = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Meals" & "\avocado.jpg")
        Fruittext = "Avocado"
    End Sub
End Module

