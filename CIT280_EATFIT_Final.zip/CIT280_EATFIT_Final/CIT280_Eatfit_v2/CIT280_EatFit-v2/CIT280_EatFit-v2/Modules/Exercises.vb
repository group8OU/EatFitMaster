﻿Public Module Exercises
    'Public Workout Drawing Objects
    Public lwo1, lwo2, lwo3, lwo4, lwo5, lwo6
    Public hwo1, hwo2, hwo3, hwo4, hwo5, hwo6, hwo7, hwo8
    'workout selection
    Public Sub selectlightworkout()
        Randomize()
        Dim lightchoice As Integer = Math.Ceiling(Rnd() * 4)
        Select Case True
            Case lightchoice = 1
                loadlbackbi()
            Case lightchoice = 2
                loadlchesttri()
            Case lightchoice = 3
                loadllegsshoulders()
            Case lightchoice = 4
                loadlcardiocore()
            Case Else
                MsgBox("Light workout error")
                frmLight.Close()
        End Select
    End Sub
    Public Sub selectheavyworkout()
        Randomize()
        Dim heavychoice As Integer = Math.Ceiling(Rnd() * 4)
        Select Case True
            Case heavychoice = 1
                loadhbackbi()
            Case heavychoice = 2
                loadhchesttri()
            Case heavychoice = 3
                loadhlegsshoulders()
            Case heavychoice = 4
                loadhcardiocore()
            Case Else
                MsgBox("Light workout error")
                frmLight.Close()
        End Select
    End Sub
    Public Sub loadlbackbi()
        lwo1 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\picture_name.jpg")
        lwo2 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\picture_name.jpg")
        lwo3 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\picture_name.jpg")
        lwo4 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\picture_name.jpg")
        lwo5 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\picture_name.jpg")
        lwo6 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\picture_name.jpg")
    End Sub
    Public Sub loadlchesttri()
        lwo1 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\picture_name.jpg")
        lwo2 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\picture_name.jpg")
        lwo3 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\picture_name.jpg")
        lwo4 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\picture_name.jpg")
        lwo5 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\picture_name.jpg")
        lwo6 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\picture_name.jpg")
    End Sub
    Public Sub loadllegsshoulders()
        lwo1 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\picture_name.jpg")
        lwo2 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\picture_name.jpg")
        lwo3 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\picture_name.jpg")
        lwo4 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\picture_name.jpg")
        lwo5 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\picture_name.jpg")
        lwo6 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\picture_name.jpg")
    End Sub
    Public Sub loadlcardiocore()
        lwo1 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\picture_name.jpg")
        lwo2 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\picture_name.jpg")
        lwo3 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\picture_name.jpg")
        lwo4 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\picture_name.jpg")
        lwo5 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\picture_name.jpg")
        lwo6 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\picture_name.jpg")
    End Sub
    Public Sub loadhbackbi()
        hwo1 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\picture_name.jpg")
        hwo2 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\picture_name.jpg")
        hwo3 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\picture_name.jpg")
        hwo4 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\picture_name.jpg")
        hwo5 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\picture_name.jpg")
        hwo6 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\picture_name.jpg")
        hwo7 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\picture_name.jpg")
        hwo8 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\picture_name.jpg")
    End Sub
    Public Sub loadhchesttri()
        hwo1 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\picture_name.jpg")
        hwo2 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\picture_name.jpg")
        hwo3 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\picture_name.jpg")
        hwo4 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\picture_name.jpg")
        hwo5 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\picture_name.jpg")
        hwo6 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\picture_name.jpg")
        hwo7 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\picture_name.jpg")
        hwo8 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\picture_name.jpg")
    End Sub
    Public Sub loadhlegsshoulders()
        hwo1 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\picture_name.jpg")
        hwo2 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\picture_name.jpg")
        hwo3 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\picture_name.jpg")
        hwo4 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\picture_name.jpg")
        hwo5 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\picture_name.jpg")
        hwo6 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\picture_name.jpg")
        hwo7 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\picture_name.jpg")
        hwo8 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\picture_name.jpg")
    End Sub
    Public Sub loadhcardiocore()
        hwo1 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\picture_name.jpg")
        hwo2 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\picture_name.jpg")
        hwo3 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\picture_name.jpg")
        hwo4 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\picture_name.jpg")
        hwo5 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\picture_name.jpg")
        hwo6 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\picture_name.jpg")
        hwo7 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\picture_name.jpg")
        hwo8 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\picture_name.jpg")
    End Sub
End Module
