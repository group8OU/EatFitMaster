﻿Public Class frmLight
    Private Sub frmLight_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        selectlightworkout()
        getworkouts()
    End Sub

    Private Sub getworkouts()
        pbL1.Image = lwo1
        pbL2.Image = lwo2
        pbL3.Image = lwo3
        pbL4.Image = lwo4
        pbL5.Image = lwo5
        pbL6.Image = lwo6
        txtL1.Text = lt1
        txtL2.Text = lt2
        txtL3.Text = lt3
        txtL4.Text = lt4
        txtL5.Text = lt5
        txtL6.Text = lt6

    End Sub
    Private Sub frmLight_FormClosed(sender As Object, e As FormClosedEventArgs) Handles Me.FormClosed
        clearobjectsL()
    End Sub
End Class