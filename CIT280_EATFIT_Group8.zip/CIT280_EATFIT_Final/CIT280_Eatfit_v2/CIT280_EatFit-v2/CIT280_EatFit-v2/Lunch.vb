﻿Public Class frmLunch
    Private Sub frmLunch_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        selectfruit()
        selectdrink()
        selectprotein()
        selectvegetable()
        selectgrain()
        linkobjects()
    End Sub
    Private Sub linkobjects()
        pbLFruit.Image = Fruitbox
        txtLFruit.Text = Fruittext

        pbLProtein.Image = Proteinbox
        txtLProtein.Text = Proteintext

        pbLGrain.Image = Grainbox
        txtLGrain.Text = Graintext

        pbLVegetable.Image = Vegetablebox
        txtLVegetable.Text = Vegetabletext

        pbLDrink.Image = Drinkbox
        txtLDrink.Text = Drinktext
    End Sub
    Private Sub frmLunch_FormClosed(sender As Object, e As FormClosedEventArgs) Handles Me.FormClosed
        clearobjects()
    End Sub
End Class