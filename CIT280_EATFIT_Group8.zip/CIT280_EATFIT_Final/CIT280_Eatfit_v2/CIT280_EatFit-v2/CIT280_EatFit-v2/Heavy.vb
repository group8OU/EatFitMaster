﻿Public Class frmHeavy
    Private Sub frmHeavy_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        selectheavyworkout()
        getworkouts()
    End Sub

    Private Sub getworkouts()
        pbH1.Image = hwo1
        pbH2.Image = hwo2
        pbH3.Image = hwo3
        pbH4.Image = hwo4
        pbH5.Image = hwo5
        pbH6.Image = hwo6
        pbH7.Image = hwo7
        pbH8.Image = hwo8
        txtH1.Text = ht1
        txtH2.Text = ht2
        txtH3.Text = ht3
        txtH4.Text = ht4
        txtH5.Text = ht5
        txtH6.Text = ht6
        txtH7.Text = ht7
        txtH8.Text = ht8

    End Sub
    Private Sub frmLight_FormClosed(sender As Object, e As FormClosedEventArgs) Handles Me.FormClosed
        clearobjectsH()
    End Sub
End Class