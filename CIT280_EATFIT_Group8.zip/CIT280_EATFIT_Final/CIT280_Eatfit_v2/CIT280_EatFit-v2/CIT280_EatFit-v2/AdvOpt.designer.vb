﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmAdvOpt
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.chkPeanut = New System.Windows.Forms.CheckBox()
        Me.chkTreeNut = New System.Windows.Forms.CheckBox()
        Me.chkEggs = New System.Windows.Forms.CheckBox()
        Me.chkFish = New System.Windows.Forms.CheckBox()
        Me.chkShellfish = New System.Windows.Forms.CheckBox()
        Me.chkLactose = New System.Windows.Forms.CheckBox()
        Me.chkWheat = New System.Windows.Forms.CheckBox()
        Me.lblDiet = New System.Windows.Forms.Label()
        Me.lblAllergies = New System.Windows.Forms.Label()
        Me.chkSoy = New System.Windows.Forms.CheckBox()
        Me.btnBack_advop = New System.Windows.Forms.Button()
        Me.radNone = New System.Windows.Forms.RadioButton()
        Me.radVegetarian = New System.Windows.Forms.RadioButton()
        Me.radVegan = New System.Windows.Forms.RadioButton()
        Me.radGlutenfree = New System.Windows.Forms.RadioButton()
        Me.btnDeleteProfile = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'chkPeanut
        '
        Me.chkPeanut.Appearance = System.Windows.Forms.Appearance.Button
        Me.chkPeanut.AutoSize = True
        Me.chkPeanut.BackColor = System.Drawing.Color.Transparent
        Me.chkPeanut.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.chkPeanut.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.chkPeanut.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.chkPeanut.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.chkPeanut.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.chkPeanut.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkPeanut.ForeColor = System.Drawing.Color.Transparent
        Me.chkPeanut.Location = New System.Drawing.Point(136, 58)
        Me.chkPeanut.Name = "chkPeanut"
        Me.chkPeanut.Size = New System.Drawing.Size(74, 26)
        Me.chkPeanut.TabIndex = 16
        Me.chkPeanut.Text = "Peanuts"
        Me.chkPeanut.UseVisualStyleBackColor = False
        '
        'chkTreeNut
        '
        Me.chkTreeNut.Appearance = System.Windows.Forms.Appearance.Button
        Me.chkTreeNut.AutoSize = True
        Me.chkTreeNut.BackColor = System.Drawing.Color.Transparent
        Me.chkTreeNut.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.chkTreeNut.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.chkTreeNut.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.chkTreeNut.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.chkTreeNut.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.chkTreeNut.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkTreeNut.ForeColor = System.Drawing.Color.Transparent
        Me.chkTreeNut.Location = New System.Drawing.Point(136, 90)
        Me.chkTreeNut.Name = "chkTreeNut"
        Me.chkTreeNut.Size = New System.Drawing.Size(86, 26)
        Me.chkTreeNut.TabIndex = 17
        Me.chkTreeNut.Text = "Tree Nuts"
        Me.chkTreeNut.UseVisualStyleBackColor = False
        '
        'chkEggs
        '
        Me.chkEggs.Appearance = System.Windows.Forms.Appearance.Button
        Me.chkEggs.AutoSize = True
        Me.chkEggs.BackColor = System.Drawing.Color.Transparent
        Me.chkEggs.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.chkEggs.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.chkEggs.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.chkEggs.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.chkEggs.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.chkEggs.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkEggs.ForeColor = System.Drawing.Color.Transparent
        Me.chkEggs.Location = New System.Drawing.Point(136, 160)
        Me.chkEggs.Name = "chkEggs"
        Me.chkEggs.Size = New System.Drawing.Size(54, 26)
        Me.chkEggs.TabIndex = 19
        Me.chkEggs.Text = "Eggs"
        Me.chkEggs.UseVisualStyleBackColor = False
        '
        'chkFish
        '
        Me.chkFish.Appearance = System.Windows.Forms.Appearance.Button
        Me.chkFish.AutoSize = True
        Me.chkFish.BackColor = System.Drawing.Color.Transparent
        Me.chkFish.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.chkFish.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.chkFish.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.chkFish.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.chkFish.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.chkFish.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkFish.ForeColor = System.Drawing.Color.Transparent
        Me.chkFish.Location = New System.Drawing.Point(235, 124)
        Me.chkFish.Name = "chkFish"
        Me.chkFish.Size = New System.Drawing.Size(47, 26)
        Me.chkFish.TabIndex = 20
        Me.chkFish.Text = "Fish"
        Me.chkFish.UseVisualStyleBackColor = False
        '
        'chkShellfish
        '
        Me.chkShellfish.Appearance = System.Windows.Forms.Appearance.Button
        Me.chkShellfish.AutoSize = True
        Me.chkShellfish.BackColor = System.Drawing.Color.Transparent
        Me.chkShellfish.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.chkShellfish.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.chkShellfish.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.chkShellfish.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.chkShellfish.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.chkShellfish.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkShellfish.ForeColor = System.Drawing.Color.Transparent
        Me.chkShellfish.Location = New System.Drawing.Point(235, 160)
        Me.chkShellfish.Name = "chkShellfish"
        Me.chkShellfish.Size = New System.Drawing.Size(77, 26)
        Me.chkShellfish.TabIndex = 21
        Me.chkShellfish.Text = "Shellfish"
        Me.chkShellfish.UseVisualStyleBackColor = False
        '
        'chkLactose
        '
        Me.chkLactose.Appearance = System.Windows.Forms.Appearance.Button
        Me.chkLactose.AutoSize = True
        Me.chkLactose.BackColor = System.Drawing.Color.Transparent
        Me.chkLactose.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.chkLactose.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.chkLactose.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.chkLactose.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.chkLactose.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.chkLactose.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkLactose.ForeColor = System.Drawing.Color.Transparent
        Me.chkLactose.Location = New System.Drawing.Point(235, 56)
        Me.chkLactose.Name = "chkLactose"
        Me.chkLactose.Size = New System.Drawing.Size(73, 26)
        Me.chkLactose.TabIndex = 22
        Me.chkLactose.Text = "Lactose"
        Me.chkLactose.UseVisualStyleBackColor = False
        '
        'chkWheat
        '
        Me.chkWheat.Appearance = System.Windows.Forms.Appearance.Button
        Me.chkWheat.AutoSize = True
        Me.chkWheat.BackColor = System.Drawing.Color.Transparent
        Me.chkWheat.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.chkWheat.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.chkWheat.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.chkWheat.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.chkWheat.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.chkWheat.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkWheat.ForeColor = System.Drawing.Color.Transparent
        Me.chkWheat.Location = New System.Drawing.Point(235, 88)
        Me.chkWheat.Name = "chkWheat"
        Me.chkWheat.Size = New System.Drawing.Size(62, 26)
        Me.chkWheat.TabIndex = 23
        Me.chkWheat.Text = "Wheat"
        Me.chkWheat.UseVisualStyleBackColor = False
        '
        'lblDiet
        '
        Me.lblDiet.AutoSize = True
        Me.lblDiet.BackColor = System.Drawing.Color.Transparent
        Me.lblDiet.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDiet.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.lblDiet.Location = New System.Drawing.Point(13, 18)
        Me.lblDiet.Name = "lblDiet"
        Me.lblDiet.Size = New System.Drawing.Size(46, 24)
        Me.lblDiet.TabIndex = 24
        Me.lblDiet.Text = "Diet"
        '
        'lblAllergies
        '
        Me.lblAllergies.AutoSize = True
        Me.lblAllergies.BackColor = System.Drawing.Color.Transparent
        Me.lblAllergies.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAllergies.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.lblAllergies.Location = New System.Drawing.Point(132, 18)
        Me.lblAllergies.Name = "lblAllergies"
        Me.lblAllergies.Size = New System.Drawing.Size(92, 24)
        Me.lblAllergies.TabIndex = 25
        Me.lblAllergies.Text = "Allergies"
        '
        'chkSoy
        '
        Me.chkSoy.Appearance = System.Windows.Forms.Appearance.Button
        Me.chkSoy.AutoSize = True
        Me.chkSoy.BackColor = System.Drawing.Color.Transparent
        Me.chkSoy.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.chkSoy.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.chkSoy.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.chkSoy.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.chkSoy.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.chkSoy.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkSoy.ForeColor = System.Drawing.Color.Transparent
        Me.chkSoy.Location = New System.Drawing.Point(136, 125)
        Me.chkSoy.Name = "chkSoy"
        Me.chkSoy.Size = New System.Drawing.Size(45, 26)
        Me.chkSoy.TabIndex = 18
        Me.chkSoy.Text = "Soy"
        Me.chkSoy.UseVisualStyleBackColor = False
        '
        'btnBack_advop
        '
        Me.btnBack_advop.BackColor = System.Drawing.Color.MediumOrchid
        Me.btnBack_advop.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnBack_advop.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBack_advop.ForeColor = System.Drawing.SystemColors.Control
        Me.btnBack_advop.Location = New System.Drawing.Point(17, 207)
        Me.btnBack_advop.Name = "btnBack_advop"
        Me.btnBack_advop.Size = New System.Drawing.Size(25, 25)
        Me.btnBack_advop.TabIndex = 30
        Me.btnBack_advop.Text = "<"
        Me.btnBack_advop.UseVisualStyleBackColor = False
        '
        'radNone
        '
        Me.radNone.Appearance = System.Windows.Forms.Appearance.Button
        Me.radNone.AutoSize = True
        Me.radNone.BackColor = System.Drawing.Color.Transparent
        Me.radNone.Checked = True
        Me.radNone.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.radNone.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.radNone.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.radNone.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.radNone.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.radNone.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radNone.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.radNone.Location = New System.Drawing.Point(17, 56)
        Me.radNone.Name = "radNone"
        Me.radNone.Size = New System.Drawing.Size(57, 28)
        Me.radNone.TabIndex = 31
        Me.radNone.TabStop = True
        Me.radNone.Text = "None"
        Me.radNone.UseVisualStyleBackColor = False
        '
        'radVegetarian
        '
        Me.radVegetarian.Appearance = System.Windows.Forms.Appearance.Button
        Me.radVegetarian.AutoSize = True
        Me.radVegetarian.BackColor = System.Drawing.Color.Transparent
        Me.radVegetarian.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.radVegetarian.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.radVegetarian.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.radVegetarian.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.radVegetarian.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.radVegetarian.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radVegetarian.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.radVegetarian.Location = New System.Drawing.Point(17, 90)
        Me.radVegetarian.Name = "radVegetarian"
        Me.radVegetarian.Size = New System.Drawing.Size(96, 28)
        Me.radVegetarian.TabIndex = 32
        Me.radVegetarian.Text = "Vegetarian"
        Me.radVegetarian.UseVisualStyleBackColor = False
        '
        'radVegan
        '
        Me.radVegan.Appearance = System.Windows.Forms.Appearance.Button
        Me.radVegan.AutoSize = True
        Me.radVegan.BackColor = System.Drawing.Color.Transparent
        Me.radVegan.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.radVegan.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.radVegan.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.radVegan.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.radVegan.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.radVegan.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radVegan.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.radVegan.Location = New System.Drawing.Point(17, 124)
        Me.radVegan.Name = "radVegan"
        Me.radVegan.Size = New System.Drawing.Size(65, 28)
        Me.radVegan.TabIndex = 33
        Me.radVegan.Text = "Vegan"
        Me.radVegan.UseVisualStyleBackColor = False
        '
        'radGlutenfree
        '
        Me.radGlutenfree.Appearance = System.Windows.Forms.Appearance.Button
        Me.radGlutenfree.AutoSize = True
        Me.radGlutenfree.BackColor = System.Drawing.Color.Transparent
        Me.radGlutenfree.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.radGlutenfree.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.radGlutenfree.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.radGlutenfree.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.radGlutenfree.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.radGlutenfree.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radGlutenfree.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.radGlutenfree.Location = New System.Drawing.Point(17, 158)
        Me.radGlutenfree.Name = "radGlutenfree"
        Me.radGlutenfree.Size = New System.Drawing.Size(100, 28)
        Me.radGlutenfree.TabIndex = 34
        Me.radGlutenfree.Text = "Gluten Free"
        Me.radGlutenfree.UseVisualStyleBackColor = False
        '
        'btnDeleteProfile
        '
        Me.btnDeleteProfile.BackColor = System.Drawing.Color.Red
        Me.btnDeleteProfile.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.btnDeleteProfile.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnDeleteProfile.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDeleteProfile.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.btnDeleteProfile.Location = New System.Drawing.Point(239, 207)
        Me.btnDeleteProfile.Name = "btnDeleteProfile"
        Me.btnDeleteProfile.Size = New System.Drawing.Size(94, 25)
        Me.btnDeleteProfile.TabIndex = 35
        Me.btnDeleteProfile.Text = "Delete Profile"
        Me.btnDeleteProfile.UseVisualStyleBackColor = False
        '
        'frmAdvOpt
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.LightSeaGreen
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(341, 241)
        Me.ControlBox = False
        Me.Controls.Add(Me.btnDeleteProfile)
        Me.Controls.Add(Me.radGlutenfree)
        Me.Controls.Add(Me.radVegan)
        Me.Controls.Add(Me.radVegetarian)
        Me.Controls.Add(Me.radNone)
        Me.Controls.Add(Me.btnBack_advop)
        Me.Controls.Add(Me.lblAllergies)
        Me.Controls.Add(Me.chkWheat)
        Me.Controls.Add(Me.chkLactose)
        Me.Controls.Add(Me.chkShellfish)
        Me.Controls.Add(Me.chkFish)
        Me.Controls.Add(Me.chkEggs)
        Me.Controls.Add(Me.chkSoy)
        Me.Controls.Add(Me.chkTreeNut)
        Me.Controls.Add(Me.chkPeanut)
        Me.Controls.Add(Me.lblDiet)
        Me.DoubleBuffered = True
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmAdvOpt"
        Me.ShowIcon = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Options"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents chkPeanut As CheckBox
    Friend WithEvents chkTreeNut As CheckBox
    Friend WithEvents chkEggs As CheckBox
    Friend WithEvents chkFish As CheckBox
    Friend WithEvents chkShellfish As CheckBox
    Friend WithEvents chkLactose As CheckBox
    Friend WithEvents chkWheat As CheckBox
    Friend WithEvents lblDiet As Label
    Friend WithEvents lblAllergies As Label
    Friend WithEvents chkSoy As System.Windows.Forms.CheckBox
    Friend WithEvents btnBack_advop As System.Windows.Forms.Button
    Friend WithEvents radNone As System.Windows.Forms.RadioButton
    Friend WithEvents radVegetarian As System.Windows.Forms.RadioButton
    Friend WithEvents radVegan As System.Windows.Forms.RadioButton
    Friend WithEvents radGlutenfree As System.Windows.Forms.RadioButton
    Friend WithEvents btnDeleteProfile As System.Windows.Forms.Button
End Class
