﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmSnack
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtSDrink = New System.Windows.Forms.TextBox()
        Me.txtSFruit = New System.Windows.Forms.TextBox()
        Me.txtSGrain = New System.Windows.Forms.TextBox()
        Me.txtSProtein = New System.Windows.Forms.TextBox()
        Me.pbSDrink = New System.Windows.Forms.PictureBox()
        Me.pbSFruit = New System.Windows.Forms.PictureBox()
        Me.pbSGrain = New System.Windows.Forms.PictureBox()
        Me.pbSProtein = New System.Windows.Forms.PictureBox()
        Me.btnrefresh = New System.Windows.Forms.Button()
        Me.btnBack_advop = New System.Windows.Forms.Button()
        Me.lblsnack = New System.Windows.Forms.Label()
        CType(Me.pbSDrink, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbSFruit, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbSGrain, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbSProtein, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'txtSDrink
        '
        Me.txtSDrink.Location = New System.Drawing.Point(330, 156)
        Me.txtSDrink.Name = "txtSDrink"
        Me.txtSDrink.ReadOnly = True
        Me.txtSDrink.Size = New System.Drawing.Size(100, 20)
        Me.txtSDrink.TabIndex = 35
        Me.txtSDrink.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtSFruit
        '
        Me.txtSFruit.Location = New System.Drawing.Point(224, 156)
        Me.txtSFruit.Name = "txtSFruit"
        Me.txtSFruit.ReadOnly = True
        Me.txtSFruit.Size = New System.Drawing.Size(100, 20)
        Me.txtSFruit.TabIndex = 34
        Me.txtSFruit.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtSGrain
        '
        Me.txtSGrain.Location = New System.Drawing.Point(118, 156)
        Me.txtSGrain.Name = "txtSGrain"
        Me.txtSGrain.ReadOnly = True
        Me.txtSGrain.Size = New System.Drawing.Size(100, 20)
        Me.txtSGrain.TabIndex = 33
        Me.txtSGrain.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtSProtein
        '
        Me.txtSProtein.Location = New System.Drawing.Point(12, 156)
        Me.txtSProtein.Name = "txtSProtein"
        Me.txtSProtein.ReadOnly = True
        Me.txtSProtein.Size = New System.Drawing.Size(100, 20)
        Me.txtSProtein.TabIndex = 32
        Me.txtSProtein.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'pbSDrink
        '
        Me.pbSDrink.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pbSDrink.Location = New System.Drawing.Point(330, 41)
        Me.pbSDrink.Name = "pbSDrink"
        Me.pbSDrink.Size = New System.Drawing.Size(100, 100)
        Me.pbSDrink.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbSDrink.TabIndex = 31
        Me.pbSDrink.TabStop = False
        '
        'pbSFruit
        '
        Me.pbSFruit.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pbSFruit.Location = New System.Drawing.Point(224, 41)
        Me.pbSFruit.Name = "pbSFruit"
        Me.pbSFruit.Size = New System.Drawing.Size(100, 100)
        Me.pbSFruit.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbSFruit.TabIndex = 30
        Me.pbSFruit.TabStop = False
        '
        'pbSGrain
        '
        Me.pbSGrain.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pbSGrain.Location = New System.Drawing.Point(118, 41)
        Me.pbSGrain.Name = "pbSGrain"
        Me.pbSGrain.Size = New System.Drawing.Size(100, 100)
        Me.pbSGrain.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbSGrain.TabIndex = 29
        Me.pbSGrain.TabStop = False
        '
        'pbSProtein
        '
        Me.pbSProtein.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pbSProtein.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pbSProtein.Location = New System.Drawing.Point(12, 41)
        Me.pbSProtein.Name = "pbSProtein"
        Me.pbSProtein.Size = New System.Drawing.Size(100, 100)
        Me.pbSProtein.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbSProtein.TabIndex = 28
        Me.pbSProtein.TabStop = False
        '
        'btnrefresh
        '
        Me.btnrefresh.BackColor = System.Drawing.Color.RoyalBlue
        Me.btnrefresh.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.btnrefresh.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnrefresh.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnrefresh.ForeColor = System.Drawing.Color.White
        Me.btnrefresh.Location = New System.Drawing.Point(374, 9)
        Me.btnrefresh.Name = "btnrefresh"
        Me.btnrefresh.Size = New System.Drawing.Size(25, 25)
        Me.btnrefresh.TabIndex = 36
        Me.btnrefresh.Text = "!"
        Me.btnrefresh.UseVisualStyleBackColor = False
        '
        'btnBack_advop
        '
        Me.btnBack_advop.BackColor = System.Drawing.Color.Crimson
        Me.btnBack_advop.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnBack_advop.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBack_advop.ForeColor = System.Drawing.SystemColors.Control
        Me.btnBack_advop.Location = New System.Drawing.Point(405, 9)
        Me.btnBack_advop.Name = "btnBack_advop"
        Me.btnBack_advop.Size = New System.Drawing.Size(25, 25)
        Me.btnBack_advop.TabIndex = 37
        Me.btnBack_advop.Text = "X"
        Me.btnBack_advop.UseVisualStyleBackColor = False
        '
        'lblsnack
        '
        Me.lblsnack.AutoSize = True
        Me.lblsnack.BackColor = System.Drawing.Color.Transparent
        Me.lblsnack.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblsnack.ForeColor = System.Drawing.Color.White
        Me.lblsnack.Location = New System.Drawing.Point(7, 9)
        Me.lblsnack.Name = "lblsnack"
        Me.lblsnack.Size = New System.Drawing.Size(84, 29)
        Me.lblsnack.TabIndex = 38
        Me.lblsnack.Text = "Snack"
        '
        'frmSnack
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.LightSkyBlue
        Me.ClientSize = New System.Drawing.Size(442, 189)
        Me.ControlBox = False
        Me.Controls.Add(Me.lblsnack)
        Me.Controls.Add(Me.btnBack_advop)
        Me.Controls.Add(Me.btnrefresh)
        Me.Controls.Add(Me.txtSDrink)
        Me.Controls.Add(Me.txtSFruit)
        Me.Controls.Add(Me.txtSGrain)
        Me.Controls.Add(Me.txtSProtein)
        Me.Controls.Add(Me.pbSDrink)
        Me.Controls.Add(Me.pbSFruit)
        Me.Controls.Add(Me.pbSGrain)
        Me.Controls.Add(Me.pbSProtein)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmSnack"
        Me.ShowIcon = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Snack"
        CType(Me.pbSDrink, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbSFruit, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbSGrain, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbSProtein, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Private WithEvents txtSDrink As TextBox
    Private WithEvents txtSFruit As TextBox
    Private WithEvents txtSGrain As TextBox
    Private WithEvents txtSProtein As TextBox
    Private WithEvents pbSDrink As PictureBox
    Private WithEvents pbSFruit As PictureBox
    Private WithEvents pbSGrain As PictureBox
    Public WithEvents pbSProtein As System.Windows.Forms.PictureBox
    Friend WithEvents btnrefresh As System.Windows.Forms.Button
    Friend WithEvents btnBack_advop As System.Windows.Forms.Button
    Friend WithEvents lblsnack As System.Windows.Forms.Label
End Class
