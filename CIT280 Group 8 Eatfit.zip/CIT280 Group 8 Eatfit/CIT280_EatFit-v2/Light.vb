﻿'Credit: Ian Teal (50%), Hassan Abdullah (50%)
Public Class frmLight
    'Load event
    Private Sub frmLight_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.BackgroundImage = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Backgrounds" & "\navy_bg.png")
        startlight()
    End Sub
    Private Sub frmLight_FormClosed(sender As Object, e As FormClosedEventArgs) Handles Me.FormClosed
        clearobjectsL()
    End Sub
    Private Sub startlight()
        selectlightworkout()
        getworkouts()
    End Sub
    'Assign Module objects
    Private Sub getworkouts()
        pbL1.Image = lwo1
        pbL2.Image = lwo2
        pbL3.Image = lwo3
        pbL4.Image = lwo4
        pbL5.Image = lwo5
        pbL6.Image = lwo6
        txtL1.Text = lt1
        txtL2.Text = lt2
        txtL3.Text = lt3
        txtL4.Text = lt4
        txtL5.Text = lt5
        txtL6.Text = lt6
    End Sub
    'Button clicks
    Private Sub btnBack_advop_Click(sender As Object, e As EventArgs) Handles btnBack_advop.Click
        Me.Close()
    End Sub
    Private Sub btnrefresh_Click(sender As Object, e As EventArgs) Handles btnrefresh.Click
        startlight()
    End Sub
End Class