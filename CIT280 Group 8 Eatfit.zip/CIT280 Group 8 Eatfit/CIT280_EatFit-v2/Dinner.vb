﻿'Credit: Peter Iacona (33%), Ian Teal (33%), Teri Rhodes(33%)
Public Class frmDinner
    'Load event
    Private Sub frmDinner_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.BackgroundImage = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Backgrounds" & "\yellow_bg.png")
        startdinner()
    End Sub
    Private Sub frmSnack_FormClosed(sender As Object, e As FormClosedEventArgs) Handles Me.FormClosed
        clearobjects()
    End Sub
    Private Sub startdinner()
        selectfruit()
        selectdrink()
        selectprotein()
        selectvegetable()
        selectgrain()
        linkobjects()
    End Sub
    'Assign Module objects
    Private Sub linkobjects()
        pbDFruit.Image = Fruitbox
        txtDFruit.Text = Fruittext
        pbDProtein.Image = Proteinbox
        txtDProtein.Text = Proteintext
        pbDGrain.Image = Grainbox
        txtDGrain.Text = Graintext
        pbDVegetable.Image = Vegetablebox
        txtDVegetable.Text = Vegetabletext
        pbDDrink.Image = Drinkbox
        txtDDrink.Text = Drinktext
    End Sub
    'Button clicks
    Private Sub btnrefresh_Click(sender As Object, e As EventArgs) Handles btnrefresh.Click
        startdinner()
    End Sub
    Private Sub btnBack_advop_Click(sender As Object, e As EventArgs) Handles btnBack_advop.Click
        Me.Close()
    End Sub
End Class