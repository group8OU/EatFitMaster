﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmLunch
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtLDrink = New System.Windows.Forms.TextBox()
        Me.txtLFruit = New System.Windows.Forms.TextBox()
        Me.txtLGrain = New System.Windows.Forms.TextBox()
        Me.txtLVegetable = New System.Windows.Forms.TextBox()
        Me.txtLProtein = New System.Windows.Forms.TextBox()
        Me.pbLDrink = New System.Windows.Forms.PictureBox()
        Me.pbLFruit = New System.Windows.Forms.PictureBox()
        Me.pbLGrain = New System.Windows.Forms.PictureBox()
        Me.pbLVegetable = New System.Windows.Forms.PictureBox()
        Me.pbLProtein = New System.Windows.Forms.PictureBox()
        Me.btnBack_advop = New System.Windows.Forms.Button()
        Me.btnrefresh = New System.Windows.Forms.Button()
        Me.lbllunch = New System.Windows.Forms.Label()
        CType(Me.pbLDrink, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbLFruit, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbLGrain, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbLVegetable, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbLProtein, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'txtLDrink
        '
        Me.txtLDrink.Location = New System.Drawing.Point(436, 160)
        Me.txtLDrink.Name = "txtLDrink"
        Me.txtLDrink.ReadOnly = True
        Me.txtLDrink.Size = New System.Drawing.Size(100, 20)
        Me.txtLDrink.TabIndex = 29
        Me.txtLDrink.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtLFruit
        '
        Me.txtLFruit.Location = New System.Drawing.Point(330, 160)
        Me.txtLFruit.Name = "txtLFruit"
        Me.txtLFruit.ReadOnly = True
        Me.txtLFruit.Size = New System.Drawing.Size(100, 20)
        Me.txtLFruit.TabIndex = 28
        Me.txtLFruit.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtLGrain
        '
        Me.txtLGrain.Location = New System.Drawing.Point(224, 160)
        Me.txtLGrain.Name = "txtLGrain"
        Me.txtLGrain.ReadOnly = True
        Me.txtLGrain.Size = New System.Drawing.Size(100, 20)
        Me.txtLGrain.TabIndex = 27
        Me.txtLGrain.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtLVegetable
        '
        Me.txtLVegetable.Location = New System.Drawing.Point(118, 160)
        Me.txtLVegetable.Name = "txtLVegetable"
        Me.txtLVegetable.ReadOnly = True
        Me.txtLVegetable.Size = New System.Drawing.Size(100, 20)
        Me.txtLVegetable.TabIndex = 26
        Me.txtLVegetable.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtLProtein
        '
        Me.txtLProtein.Location = New System.Drawing.Point(12, 160)
        Me.txtLProtein.Name = "txtLProtein"
        Me.txtLProtein.ReadOnly = True
        Me.txtLProtein.Size = New System.Drawing.Size(100, 20)
        Me.txtLProtein.TabIndex = 25
        Me.txtLProtein.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'pbLDrink
        '
        Me.pbLDrink.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.pbLDrink.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pbLDrink.Location = New System.Drawing.Point(436, 44)
        Me.pbLDrink.Name = "pbLDrink"
        Me.pbLDrink.Size = New System.Drawing.Size(100, 100)
        Me.pbLDrink.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbLDrink.TabIndex = 24
        Me.pbLDrink.TabStop = False
        '
        'pbLFruit
        '
        Me.pbLFruit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.pbLFruit.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pbLFruit.Location = New System.Drawing.Point(330, 44)
        Me.pbLFruit.Name = "pbLFruit"
        Me.pbLFruit.Size = New System.Drawing.Size(100, 100)
        Me.pbLFruit.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbLFruit.TabIndex = 23
        Me.pbLFruit.TabStop = False
        '
        'pbLGrain
        '
        Me.pbLGrain.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.pbLGrain.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pbLGrain.Location = New System.Drawing.Point(224, 44)
        Me.pbLGrain.Name = "pbLGrain"
        Me.pbLGrain.Size = New System.Drawing.Size(100, 100)
        Me.pbLGrain.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbLGrain.TabIndex = 22
        Me.pbLGrain.TabStop = False
        '
        'pbLVegetable
        '
        Me.pbLVegetable.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.pbLVegetable.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pbLVegetable.Location = New System.Drawing.Point(118, 44)
        Me.pbLVegetable.Name = "pbLVegetable"
        Me.pbLVegetable.Size = New System.Drawing.Size(100, 100)
        Me.pbLVegetable.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbLVegetable.TabIndex = 21
        Me.pbLVegetable.TabStop = False
        '
        'pbLProtein
        '
        Me.pbLProtein.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.pbLProtein.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pbLProtein.Location = New System.Drawing.Point(12, 44)
        Me.pbLProtein.Name = "pbLProtein"
        Me.pbLProtein.Size = New System.Drawing.Size(100, 100)
        Me.pbLProtein.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbLProtein.TabIndex = 20
        Me.pbLProtein.TabStop = False
        '
        'btnBack_advop
        '
        Me.btnBack_advop.BackColor = System.Drawing.Color.Crimson
        Me.btnBack_advop.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnBack_advop.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBack_advop.ForeColor = System.Drawing.SystemColors.Control
        Me.btnBack_advop.Location = New System.Drawing.Point(510, 12)
        Me.btnBack_advop.Name = "btnBack_advop"
        Me.btnBack_advop.Size = New System.Drawing.Size(25, 25)
        Me.btnBack_advop.TabIndex = 39
        Me.btnBack_advop.Text = "X"
        Me.btnBack_advop.UseVisualStyleBackColor = False
        '
        'btnrefresh
        '
        Me.btnrefresh.BackColor = System.Drawing.Color.RoyalBlue
        Me.btnrefresh.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.btnrefresh.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnrefresh.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnrefresh.ForeColor = System.Drawing.Color.White
        Me.btnrefresh.Location = New System.Drawing.Point(479, 12)
        Me.btnrefresh.Name = "btnrefresh"
        Me.btnrefresh.Size = New System.Drawing.Size(25, 25)
        Me.btnrefresh.TabIndex = 38
        Me.btnrefresh.Text = "!"
        Me.btnrefresh.UseVisualStyleBackColor = False
        '
        'lbllunch
        '
        Me.lbllunch.AutoSize = True
        Me.lbllunch.BackColor = System.Drawing.Color.Transparent
        Me.lbllunch.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbllunch.ForeColor = System.Drawing.Color.White
        Me.lbllunch.Location = New System.Drawing.Point(12, 9)
        Me.lbllunch.Name = "lbllunch"
        Me.lbllunch.Size = New System.Drawing.Size(82, 29)
        Me.lbllunch.TabIndex = 40
        Me.lbllunch.Text = "Lunch"
        '
        'frmLunch
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.SeaGreen
        Me.ClientSize = New System.Drawing.Size(550, 195)
        Me.ControlBox = False
        Me.Controls.Add(Me.lbllunch)
        Me.Controls.Add(Me.btnBack_advop)
        Me.Controls.Add(Me.btnrefresh)
        Me.Controls.Add(Me.txtLDrink)
        Me.Controls.Add(Me.txtLFruit)
        Me.Controls.Add(Me.txtLGrain)
        Me.Controls.Add(Me.txtLVegetable)
        Me.Controls.Add(Me.txtLProtein)
        Me.Controls.Add(Me.pbLDrink)
        Me.Controls.Add(Me.pbLFruit)
        Me.Controls.Add(Me.pbLGrain)
        Me.Controls.Add(Me.pbLVegetable)
        Me.Controls.Add(Me.pbLProtein)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmLunch"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Lunch"
        CType(Me.pbLDrink, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbLFruit, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbLGrain, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbLVegetable, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbLProtein, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Private WithEvents txtLDrink As TextBox
    Private WithEvents txtLFruit As TextBox
    Private WithEvents txtLGrain As TextBox
    Private WithEvents txtLVegetable As TextBox
    Private WithEvents txtLProtein As TextBox
    Private WithEvents pbLDrink As PictureBox
    Private WithEvents pbLFruit As PictureBox
    Private WithEvents pbLGrain As PictureBox
    Private WithEvents pbLVegetable As PictureBox
    Private WithEvents pbLProtein As PictureBox
    Friend WithEvents btnBack_advop As System.Windows.Forms.Button
    Friend WithEvents btnrefresh As System.Windows.Forms.Button
    Friend WithEvents lbllunch As System.Windows.Forms.Label
End Class
