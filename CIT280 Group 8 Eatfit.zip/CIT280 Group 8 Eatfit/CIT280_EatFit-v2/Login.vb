﻿Imports System.IO
Public Class Login
    'button clicks
    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnReturn.Click
        loginName = txtLoginName.Text
        If My.Computer.FileSystem.FileExists(loginName) Then
            frmWelcome.Show()
            Me.Close()
        Else
            MsgBox("Profile not found")
        End If
    End Sub
    Private Sub btnNew_Click(sender As Object, e As EventArgs) Handles btnNew.Click
        window_basicinfo.Show()
        Me.Close()
    End Sub
    Private Sub picLogin_Click(sender As Object, e As EventArgs) Handles picLogin.Click

    End Sub
    'load images
    Private Sub Login_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        picLogin.Image = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Backgrounds" & "\eatfitlogo.png")
        Me.BackgroundImage = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Backgrounds" & "\teal_bg.png")
    End Sub
End Class
