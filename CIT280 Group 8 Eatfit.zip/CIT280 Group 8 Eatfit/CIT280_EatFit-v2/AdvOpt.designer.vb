﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmAdvOpt
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.chkPeanut = New System.Windows.Forms.CheckBox()
        Me.lblDiet = New System.Windows.Forms.Label()
        Me.lblAllergies = New System.Windows.Forms.Label()
        Me.btnBack_advop = New System.Windows.Forms.Button()
        Me.radNone = New System.Windows.Forms.RadioButton()
        Me.radVegetarian = New System.Windows.Forms.RadioButton()
        Me.btnDeleteProfile = New System.Windows.Forms.Button()
        Me.chkEggs = New System.Windows.Forms.CheckBox()
        Me.SuspendLayout()
        '
        'chkPeanut
        '
        Me.chkPeanut.Appearance = System.Windows.Forms.Appearance.Button
        Me.chkPeanut.AutoSize = True
        Me.chkPeanut.BackColor = System.Drawing.Color.Transparent
        Me.chkPeanut.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.chkPeanut.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.chkPeanut.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.chkPeanut.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.chkPeanut.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.chkPeanut.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkPeanut.ForeColor = System.Drawing.Color.Transparent
        Me.chkPeanut.Location = New System.Drawing.Point(136, 58)
        Me.chkPeanut.Name = "chkPeanut"
        Me.chkPeanut.Size = New System.Drawing.Size(74, 26)
        Me.chkPeanut.TabIndex = 16
        Me.chkPeanut.Text = "Peanuts"
        Me.chkPeanut.UseVisualStyleBackColor = False
        '
        'lblDiet
        '
        Me.lblDiet.AutoSize = True
        Me.lblDiet.BackColor = System.Drawing.Color.Transparent
        Me.lblDiet.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDiet.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.lblDiet.Location = New System.Drawing.Point(13, 18)
        Me.lblDiet.Name = "lblDiet"
        Me.lblDiet.Size = New System.Drawing.Size(46, 24)
        Me.lblDiet.TabIndex = 24
        Me.lblDiet.Text = "Diet"
        '
        'lblAllergies
        '
        Me.lblAllergies.AutoSize = True
        Me.lblAllergies.BackColor = System.Drawing.Color.Transparent
        Me.lblAllergies.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAllergies.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.lblAllergies.Location = New System.Drawing.Point(132, 18)
        Me.lblAllergies.Name = "lblAllergies"
        Me.lblAllergies.Size = New System.Drawing.Size(92, 24)
        Me.lblAllergies.TabIndex = 25
        Me.lblAllergies.Text = "Allergies"
        '
        'btnBack_advop
        '
        Me.btnBack_advop.BackColor = System.Drawing.Color.MediumOrchid
        Me.btnBack_advop.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnBack_advop.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBack_advop.ForeColor = System.Drawing.SystemColors.Control
        Me.btnBack_advop.Location = New System.Drawing.Point(12, 144)
        Me.btnBack_advop.Name = "btnBack_advop"
        Me.btnBack_advop.Size = New System.Drawing.Size(25, 25)
        Me.btnBack_advop.TabIndex = 30
        Me.btnBack_advop.Text = "<"
        Me.btnBack_advop.UseVisualStyleBackColor = False
        '
        'radNone
        '
        Me.radNone.Appearance = System.Windows.Forms.Appearance.Button
        Me.radNone.AutoSize = True
        Me.radNone.BackColor = System.Drawing.Color.Transparent
        Me.radNone.Checked = True
        Me.radNone.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.radNone.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.radNone.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.radNone.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.radNone.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.radNone.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radNone.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.radNone.Location = New System.Drawing.Point(17, 56)
        Me.radNone.Name = "radNone"
        Me.radNone.Size = New System.Drawing.Size(57, 28)
        Me.radNone.TabIndex = 31
        Me.radNone.TabStop = True
        Me.radNone.Text = "None"
        Me.radNone.UseVisualStyleBackColor = False
        '
        'radVegetarian
        '
        Me.radVegetarian.Appearance = System.Windows.Forms.Appearance.Button
        Me.radVegetarian.AutoSize = True
        Me.radVegetarian.BackColor = System.Drawing.Color.Transparent
        Me.radVegetarian.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.radVegetarian.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.radVegetarian.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.radVegetarian.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.radVegetarian.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.radVegetarian.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radVegetarian.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.radVegetarian.Location = New System.Drawing.Point(17, 90)
        Me.radVegetarian.Name = "radVegetarian"
        Me.radVegetarian.Size = New System.Drawing.Size(96, 28)
        Me.radVegetarian.TabIndex = 32
        Me.radVegetarian.Text = "Vegetarian"
        Me.radVegetarian.UseVisualStyleBackColor = False
        '
        'btnDeleteProfile
        '
        Me.btnDeleteProfile.BackColor = System.Drawing.Color.Red
        Me.btnDeleteProfile.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.btnDeleteProfile.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnDeleteProfile.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDeleteProfile.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.btnDeleteProfile.Location = New System.Drawing.Point(139, 144)
        Me.btnDeleteProfile.Name = "btnDeleteProfile"
        Me.btnDeleteProfile.Size = New System.Drawing.Size(94, 25)
        Me.btnDeleteProfile.TabIndex = 35
        Me.btnDeleteProfile.Text = "Delete Profile"
        Me.btnDeleteProfile.UseVisualStyleBackColor = False
        '
        'chkEggs
        '
        Me.chkEggs.Appearance = System.Windows.Forms.Appearance.Button
        Me.chkEggs.AutoSize = True
        Me.chkEggs.BackColor = System.Drawing.Color.Transparent
        Me.chkEggs.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.chkEggs.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.chkEggs.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.chkEggs.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.chkEggs.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.chkEggs.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkEggs.ForeColor = System.Drawing.Color.Transparent
        Me.chkEggs.Location = New System.Drawing.Point(136, 92)
        Me.chkEggs.Name = "chkEggs"
        Me.chkEggs.Size = New System.Drawing.Size(54, 26)
        Me.chkEggs.TabIndex = 19
        Me.chkEggs.Text = "Eggs"
        Me.chkEggs.UseVisualStyleBackColor = False
        '
        'frmAdvOpt
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.LightSeaGreen
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(241, 179)
        Me.ControlBox = False
        Me.Controls.Add(Me.btnDeleteProfile)
        Me.Controls.Add(Me.radVegetarian)
        Me.Controls.Add(Me.radNone)
        Me.Controls.Add(Me.btnBack_advop)
        Me.Controls.Add(Me.lblAllergies)
        Me.Controls.Add(Me.chkEggs)
        Me.Controls.Add(Me.chkPeanut)
        Me.Controls.Add(Me.lblDiet)
        Me.DoubleBuffered = True
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmAdvOpt"
        Me.ShowIcon = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Options"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents chkPeanut As CheckBox
    Friend WithEvents lblDiet As Label
    Friend WithEvents lblAllergies As Label
    Friend WithEvents btnBack_advop As System.Windows.Forms.Button
    Friend WithEvents radNone As System.Windows.Forms.RadioButton
    Friend WithEvents radVegetarian As System.Windows.Forms.RadioButton
    Friend WithEvents btnDeleteProfile As System.Windows.Forms.Button
    Friend WithEvents chkEggs As System.Windows.Forms.CheckBox
End Class
