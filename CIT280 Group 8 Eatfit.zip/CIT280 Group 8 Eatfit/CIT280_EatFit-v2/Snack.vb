﻿Public Class frmSnack
    Private Sub frmSnack_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.BackgroundImage = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Backgrounds" & "\orange_bg.png")
        snackstart()
    End Sub
    Private Sub linkobjects()
        pbSFruit.Image = Fruitbox
        txtSFruit.Text = Fruittext
        pbSProtein.Image = Proteinbox
        txtSProtein.Text = Proteintext
        pbSGrain.Image = Grainbox
        txtSGrain.Text = Graintext
        pbSDrink.Image = Drinkbox
        txtSDrink.Text = Drinktext
    End Sub
    Private Sub frmSnack_FormClosed(sender As Object, e As FormClosedEventArgs) Handles Me.FormClosed
        clearobjects()
    End Sub
    Private Sub btnrefresh_Click(sender As Object, e As EventArgs) Handles btnrefresh.Click
        snackstart()
    End Sub
    Private Sub btnBack_advop_Click(sender As Object, e As EventArgs) Handles btnBack_advop.Click
        Me.Close()
    End Sub
    'load event
    Private Sub snackstart()
        selectdrink()
        selectfruit()
        selectprotein()
        selectgrain()
        linkobjects()
    End Sub
End Class