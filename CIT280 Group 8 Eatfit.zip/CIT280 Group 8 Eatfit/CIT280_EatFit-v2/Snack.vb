﻿'Credit: Peter Iacona (33%), Ian Teal (33%), Teri Rhodes(33%)
Public Class frmSnack
    'Load event
    Private Sub frmSnack_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.BackgroundImage = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Backgrounds" & "\orange_bg.png")
        snackstart()
    End Sub
    Private Sub frmSnack_FormClosed(sender As Object, e As FormClosedEventArgs) Handles Me.FormClosed
        clearobjects()
    End Sub
    Private Sub snackstart()
        selectdrink()
        selectfruit()
        selectprotein()
        selectgrain()
        linkobjects()
    End Sub
    'Assign Module objects
    Private Sub linkobjects()
        pbSFruit.Image = Fruitbox
        txtSFruit.Text = Fruittext
        pbSProtein.Image = Proteinbox
        txtSProtein.Text = Proteintext
        pbSGrain.Image = Grainbox
        txtSGrain.Text = Graintext
        pbSDrink.Image = Drinkbox
        txtSDrink.Text = Drinktext
    End Sub
    'Button clicks
    Private Sub btnrefresh_Click(sender As Object, e As EventArgs) Handles btnrefresh.Click
        snackstart()
    End Sub
    Private Sub btnBack_advop_Click(sender As Object, e As EventArgs) Handles btnBack_advop.Click
        Me.Close()
    End Sub
End Class