﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmWelcome
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmWelcome))
        Me.btnBreakfast = New System.Windows.Forms.Button()
        Me.btnLunch = New System.Windows.Forms.Button()
        Me.btnDinner = New System.Windows.Forms.Button()
        Me.btnSnack = New System.Windows.Forms.Button()
        Me.btnLight = New System.Windows.Forms.Button()
        Me.btnHeavy = New System.Windows.Forms.Button()
        Me.lblMeal = New System.Windows.Forms.Label()
        Me.lblWorkout = New System.Windows.Forms.Label()
        Me.btnLogout = New System.Windows.Forms.Button()
        Me.btnOptions = New System.Windows.Forms.Button()
        Me.lblwelname = New System.Windows.Forms.Label()
        Me.lblwelcome = New System.Windows.Forms.Label()
        Me.lblsex = New System.Windows.Forms.Label()
        Me.lblage = New System.Windows.Forms.Label()
        Me.lblheight = New System.Windows.Forms.Label()
        Me.lblweight = New System.Windows.Forms.Label()
        Me.lblbmi = New System.Windows.Forms.Label()
        Me.lblgw = New System.Windows.Forms.Label()
        Me.lblgd = New System.Windows.Forms.Label()
        Me.btnhm = New System.Windows.Forms.Button()
        Me.btnswap = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnBreakfast
        '
        Me.btnBreakfast.BackColor = System.Drawing.Color.Teal
        Me.btnBreakfast.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnBreakfast.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBreakfast.ForeColor = System.Drawing.SystemColors.Control
        Me.btnBreakfast.Location = New System.Drawing.Point(261, 57)
        Me.btnBreakfast.Name = "btnBreakfast"
        Me.btnBreakfast.Size = New System.Drawing.Size(103, 37)
        Me.btnBreakfast.TabIndex = 0
        Me.btnBreakfast.Text = "Breakfast"
        Me.btnBreakfast.UseVisualStyleBackColor = False
        '
        'btnLunch
        '
        Me.btnLunch.BackColor = System.Drawing.Color.Teal
        Me.btnLunch.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnLunch.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLunch.ForeColor = System.Drawing.SystemColors.Control
        Me.btnLunch.Location = New System.Drawing.Point(261, 100)
        Me.btnLunch.Name = "btnLunch"
        Me.btnLunch.Size = New System.Drawing.Size(103, 37)
        Me.btnLunch.TabIndex = 1
        Me.btnLunch.Text = "Lunch"
        Me.btnLunch.UseVisualStyleBackColor = False
        '
        'btnDinner
        '
        Me.btnDinner.BackColor = System.Drawing.Color.Teal
        Me.btnDinner.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnDinner.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDinner.ForeColor = System.Drawing.SystemColors.Control
        Me.btnDinner.Location = New System.Drawing.Point(261, 143)
        Me.btnDinner.Name = "btnDinner"
        Me.btnDinner.Size = New System.Drawing.Size(103, 37)
        Me.btnDinner.TabIndex = 2
        Me.btnDinner.Text = "Dinner"
        Me.btnDinner.UseVisualStyleBackColor = False
        '
        'btnSnack
        '
        Me.btnSnack.BackColor = System.Drawing.Color.Teal
        Me.btnSnack.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSnack.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSnack.ForeColor = System.Drawing.SystemColors.Control
        Me.btnSnack.Location = New System.Drawing.Point(261, 187)
        Me.btnSnack.Name = "btnSnack"
        Me.btnSnack.Size = New System.Drawing.Size(103, 37)
        Me.btnSnack.TabIndex = 3
        Me.btnSnack.Text = "Snack"
        Me.btnSnack.UseVisualStyleBackColor = False
        '
        'btnLight
        '
        Me.btnLight.BackColor = System.Drawing.Color.Teal
        Me.btnLight.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnLight.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLight.ForeColor = System.Drawing.SystemColors.Control
        Me.btnLight.Location = New System.Drawing.Point(382, 57)
        Me.btnLight.Name = "btnLight"
        Me.btnLight.Size = New System.Drawing.Size(103, 37)
        Me.btnLight.TabIndex = 4
        Me.btnLight.Text = "Light"
        Me.btnLight.UseVisualStyleBackColor = False
        '
        'btnHeavy
        '
        Me.btnHeavy.BackColor = System.Drawing.Color.Teal
        Me.btnHeavy.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnHeavy.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnHeavy.ForeColor = System.Drawing.SystemColors.Control
        Me.btnHeavy.Location = New System.Drawing.Point(382, 103)
        Me.btnHeavy.Name = "btnHeavy"
        Me.btnHeavy.Size = New System.Drawing.Size(103, 37)
        Me.btnHeavy.TabIndex = 5
        Me.btnHeavy.Text = "Heavy"
        Me.btnHeavy.UseVisualStyleBackColor = False
        '
        'lblMeal
        '
        Me.lblMeal.AutoSize = True
        Me.lblMeal.BackColor = System.Drawing.Color.Transparent
        Me.lblMeal.Font = New System.Drawing.Font("Verdana", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMeal.ForeColor = System.Drawing.SystemColors.Control
        Me.lblMeal.Location = New System.Drawing.Point(257, 24)
        Me.lblMeal.Name = "lblMeal"
        Me.lblMeal.Size = New System.Drawing.Size(72, 23)
        Me.lblMeal.TabIndex = 6
        Me.lblMeal.Text = "Meals"
        '
        'lblWorkout
        '
        Me.lblWorkout.AutoSize = True
        Me.lblWorkout.BackColor = System.Drawing.Color.Transparent
        Me.lblWorkout.Font = New System.Drawing.Font("Verdana", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblWorkout.ForeColor = System.Drawing.SystemColors.Control
        Me.lblWorkout.Location = New System.Drawing.Point(378, 24)
        Me.lblWorkout.Name = "lblWorkout"
        Me.lblWorkout.Size = New System.Drawing.Size(113, 23)
        Me.lblWorkout.TabIndex = 7
        Me.lblWorkout.Text = "Workouts"
        '
        'btnLogout
        '
        Me.btnLogout.BackColor = System.Drawing.Color.Red
        Me.btnLogout.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnLogout.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLogout.ForeColor = System.Drawing.SystemColors.Control
        Me.btnLogout.Location = New System.Drawing.Point(427, 290)
        Me.btnLogout.Name = "btnLogout"
        Me.btnLogout.Size = New System.Drawing.Size(67, 26)
        Me.btnLogout.TabIndex = 9
        Me.btnLogout.Text = "Logout"
        Me.btnLogout.UseVisualStyleBackColor = False
        '
        'btnOptions
        '
        Me.btnOptions.BackColor = System.Drawing.Color.DimGray
        Me.btnOptions.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnOptions.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnOptions.ForeColor = System.Drawing.SystemColors.Control
        Me.btnOptions.Location = New System.Drawing.Point(354, 290)
        Me.btnOptions.Name = "btnOptions"
        Me.btnOptions.Size = New System.Drawing.Size(67, 26)
        Me.btnOptions.TabIndex = 10
        Me.btnOptions.Text = "Options"
        Me.btnOptions.UseVisualStyleBackColor = False
        '
        'lblwelname
        '
        Me.lblwelname.AutoSize = True
        Me.lblwelname.BackColor = System.Drawing.Color.Transparent
        Me.lblwelname.Font = New System.Drawing.Font("Verdana", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblwelname.ForeColor = System.Drawing.SystemColors.Control
        Me.lblwelname.Location = New System.Drawing.Point(77, 24)
        Me.lblwelname.Name = "lblwelname"
        Me.lblwelname.Size = New System.Drawing.Size(102, 23)
        Me.lblwelname.TabIndex = 11
        Me.lblwelname.Text = "<name>"
        Me.lblwelname.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'lblwelcome
        '
        Me.lblwelcome.AutoSize = True
        Me.lblwelcome.BackColor = System.Drawing.Color.Transparent
        Me.lblwelcome.Font = New System.Drawing.Font("Verdana", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblwelcome.ForeColor = System.Drawing.SystemColors.Control
        Me.lblwelcome.Location = New System.Drawing.Point(15, 24)
        Me.lblwelcome.Name = "lblwelcome"
        Me.lblwelcome.Size = New System.Drawing.Size(65, 23)
        Me.lblwelcome.TabIndex = 12
        Me.lblwelcome.Text = "Hiya,"
        '
        'lblsex
        '
        Me.lblsex.AutoSize = True
        Me.lblsex.BackColor = System.Drawing.Color.Transparent
        Me.lblsex.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblsex.ForeColor = System.Drawing.SystemColors.Control
        Me.lblsex.Location = New System.Drawing.Point(16, 57)
        Me.lblsex.Name = "lblsex"
        Me.lblsex.Size = New System.Drawing.Size(65, 18)
        Me.lblsex.TabIndex = 13
        Me.lblsex.Text = "<sex>"
        '
        'lblage
        '
        Me.lblage.AutoSize = True
        Me.lblage.BackColor = System.Drawing.Color.Transparent
        Me.lblage.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblage.ForeColor = System.Drawing.SystemColors.Control
        Me.lblage.Location = New System.Drawing.Point(16, 76)
        Me.lblage.Name = "lblage"
        Me.lblage.Size = New System.Drawing.Size(67, 18)
        Me.lblage.TabIndex = 14
        Me.lblage.Text = "<age>"
        '
        'lblheight
        '
        Me.lblheight.AutoSize = True
        Me.lblheight.BackColor = System.Drawing.Color.Transparent
        Me.lblheight.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblheight.ForeColor = System.Drawing.SystemColors.Control
        Me.lblheight.Location = New System.Drawing.Point(16, 94)
        Me.lblheight.Name = "lblheight"
        Me.lblheight.Size = New System.Drawing.Size(89, 18)
        Me.lblheight.TabIndex = 15
        Me.lblheight.Text = "<height>"
        '
        'lblweight
        '
        Me.lblweight.AutoSize = True
        Me.lblweight.BackColor = System.Drawing.Color.Transparent
        Me.lblweight.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblweight.ForeColor = System.Drawing.SystemColors.Control
        Me.lblweight.Location = New System.Drawing.Point(16, 112)
        Me.lblweight.Name = "lblweight"
        Me.lblweight.Size = New System.Drawing.Size(94, 18)
        Me.lblweight.TabIndex = 16
        Me.lblweight.Text = "<weight>"
        '
        'lblbmi
        '
        Me.lblbmi.AutoSize = True
        Me.lblbmi.BackColor = System.Drawing.Color.Transparent
        Me.lblbmi.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblbmi.ForeColor = System.Drawing.SystemColors.Control
        Me.lblbmi.Location = New System.Drawing.Point(16, 130)
        Me.lblbmi.Name = "lblbmi"
        Me.lblbmi.Size = New System.Drawing.Size(65, 18)
        Me.lblbmi.TabIndex = 17
        Me.lblbmi.Text = "<bmi>"
        '
        'lblgw
        '
        Me.lblgw.AutoSize = True
        Me.lblgw.BackColor = System.Drawing.Color.Transparent
        Me.lblgw.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblgw.ForeColor = System.Drawing.SystemColors.Control
        Me.lblgw.Location = New System.Drawing.Point(16, 148)
        Me.lblgw.Name = "lblgw"
        Me.lblgw.Size = New System.Drawing.Size(131, 18)
        Me.lblgw.TabIndex = 18
        Me.lblgw.Text = "<goalweight>"
        '
        'lblgd
        '
        Me.lblgd.AutoSize = True
        Me.lblgd.BackColor = System.Drawing.Color.Transparent
        Me.lblgd.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblgd.ForeColor = System.Drawing.SystemColors.Control
        Me.lblgd.Location = New System.Drawing.Point(16, 166)
        Me.lblgd.Name = "lblgd"
        Me.lblgd.Size = New System.Drawing.Size(111, 18)
        Me.lblgd.TabIndex = 19
        Me.lblgd.Text = "<goaldate>"
        '
        'btnhm
        '
        Me.btnhm.BackColor = System.Drawing.Color.Orange
        Me.btnhm.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnhm.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnhm.ForeColor = System.Drawing.SystemColors.Control
        Me.btnhm.Location = New System.Drawing.Point(323, 290)
        Me.btnhm.Name = "btnhm"
        Me.btnhm.Size = New System.Drawing.Size(25, 25)
        Me.btnhm.TabIndex = 20
        Me.btnhm.Text = "?"
        Me.btnhm.UseVisualStyleBackColor = False
        '
        'btnswap
        '
        Me.btnswap.BackColor = System.Drawing.Color.DeepPink
        Me.btnswap.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnswap.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnswap.ForeColor = System.Drawing.SystemColors.Control
        Me.btnswap.Location = New System.Drawing.Point(323, 290)
        Me.btnswap.Name = "btnswap"
        Me.btnswap.Size = New System.Drawing.Size(25, 25)
        Me.btnswap.TabIndex = 21
        Me.btnswap.Text = "!"
        Me.btnswap.UseVisualStyleBackColor = False
        Me.btnswap.Visible = False
        '
        'frmWelcome
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(506, 328)
        Me.ControlBox = False
        Me.Controls.Add(Me.btnswap)
        Me.Controls.Add(Me.btnhm)
        Me.Controls.Add(Me.lblgd)
        Me.Controls.Add(Me.lblgw)
        Me.Controls.Add(Me.lblbmi)
        Me.Controls.Add(Me.lblweight)
        Me.Controls.Add(Me.lblheight)
        Me.Controls.Add(Me.lblage)
        Me.Controls.Add(Me.lblsex)
        Me.Controls.Add(Me.lblwelcome)
        Me.Controls.Add(Me.lblwelname)
        Me.Controls.Add(Me.btnOptions)
        Me.Controls.Add(Me.btnLogout)
        Me.Controls.Add(Me.lblWorkout)
        Me.Controls.Add(Me.lblMeal)
        Me.Controls.Add(Me.btnHeavy)
        Me.Controls.Add(Me.btnLight)
        Me.Controls.Add(Me.btnSnack)
        Me.Controls.Add(Me.btnDinner)
        Me.Controls.Add(Me.btnLunch)
        Me.Controls.Add(Me.btnBreakfast)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Name = "frmWelcome"
        Me.ShowIcon = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "EatFit"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnBreakfast As Button
    Friend WithEvents btnLunch As Button
    Friend WithEvents btnDinner As Button
    Friend WithEvents btnSnack As Button
    Friend WithEvents btnLight As Button
    Friend WithEvents btnHeavy As Button
    Friend WithEvents lblMeal As Label
    Friend WithEvents lblWorkout As Label
    Friend WithEvents btnLogout As System.Windows.Forms.Button
    Friend WithEvents btnOptions As System.Windows.Forms.Button
    Friend WithEvents lblwelname As System.Windows.Forms.Label
    Friend WithEvents lblwelcome As System.Windows.Forms.Label
    Friend WithEvents lblsex As System.Windows.Forms.Label
    Friend WithEvents lblage As System.Windows.Forms.Label
    Friend WithEvents lblheight As System.Windows.Forms.Label
    Friend WithEvents lblweight As System.Windows.Forms.Label
    Friend WithEvents lblbmi As System.Windows.Forms.Label
    Friend WithEvents lblgw As System.Windows.Forms.Label
    Friend WithEvents lblgd As System.Windows.Forms.Label
    Friend WithEvents btnhm As System.Windows.Forms.Button
    Friend WithEvents btnswap As System.Windows.Forms.Button
End Class
