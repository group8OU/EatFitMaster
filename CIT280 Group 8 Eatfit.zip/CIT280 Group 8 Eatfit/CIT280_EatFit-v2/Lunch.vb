﻿'Credit: Peter Iacona (33%), Ian Teal (33%), Teri Rhodes(33%)
Public Class frmLunch
    'Load event
    Private Sub frmLunch_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.BackgroundImage = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Backgrounds" & "\teal_bg.png")
        startlunch()
    End Sub
    Private Sub frmLunch_FormClosed(sender As Object, e As FormClosedEventArgs) Handles Me.FormClosed
        clearobjects()
    End Sub
    Private Sub startlunch()
        selectfruit()
        selectdrink()
        selectprotein()
        selectvegetable()
        selectgrain()
        linkobjects()
    End Sub
    'Assign Module objects
    Private Sub linkobjects()
        pbLFruit.Image = Fruitbox
        txtLFruit.Text = Fruittext

        pbLProtein.Image = Proteinbox
        txtLProtein.Text = Proteintext

        pbLGrain.Image = Grainbox
        txtLGrain.Text = Graintext

        pbLVegetable.Image = Vegetablebox
        txtLVegetable.Text = Vegetabletext

        pbLDrink.Image = Drinkbox
        txtLDrink.Text = Drinktext
    End Sub
    'Button Clicks
    Private Sub btnrefresh_Click(sender As Object, e As EventArgs) Handles btnrefresh.Click
        startlunch()
    End Sub
    Private Sub btnBack_advop_Click(sender As Object, e As EventArgs) Handles btnBack_advop.Click
        Me.Close()
    End Sub
End Class