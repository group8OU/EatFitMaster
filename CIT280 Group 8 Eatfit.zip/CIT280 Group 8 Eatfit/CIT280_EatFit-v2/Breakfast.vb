﻿Public Class frmBreakfast
    Private Sub frmBreakfast_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.BackgroundImage = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Backgrounds" & "\purple_bg.png")
        startbreakfast()
    End Sub
    Private Sub linkobjects()
        pbBFruit.Image = Fruitbox
        txtBFruit.Text = Fruittext
        pbBProtein.Image = Proteinbox
        txtBProtein.Text = Proteintext
        pbBGrain.Image = Grainbox
        txtBGrain.Text = Graintext
        pbBDrink.Image = Drinkbox
        txtBDrink.Text = Drinktext
    End Sub
    Private Sub frmSnack_FormClosed(sender As Object, e As FormClosedEventArgs) Handles Me.FormClosed
        clearobjects()
    End Sub
    Private Sub btnrefresh_Click(sender As Object, e As EventArgs) Handles btnrefresh.Click
        startbreakfast()
    End Sub
    Private Sub btnBack_advop_Click(sender As Object, e As EventArgs) Handles btnBack_advop.Click
        Me.Close()
    End Sub
    Private Sub startbreakfast()
        selectfruit()
        selectdrink()
        selectprotein()
        selectgrain()
        linkobjects()
    End Sub
End Class