﻿Public Module Exercises
    'Public Workout Drawing Objects
    Public lwo1, lwo2, lwo3, lwo4, lwo5, lwo6
    Public lt1, lt2, lt3, lt4, lt5, lt6
    Public hwo1, hwo2, hwo3, hwo4, hwo5, hwo6, hwo7, hwo8
    Public ht1, ht2, ht3, ht4, ht5, ht6, ht7, ht8
    'workout selection
    Public Sub selectlightworkout()
        Randomize()
        Dim lightchoice As Integer = Math.Ceiling(Rnd() * 4)
        Select Case True
            Case lightchoice = 1
                loadlbackbi()
            Case lightchoice = 2
                loadlchesttri()
            Case lightchoice = 3
                loadllegsshoulder()
            Case lightchoice = 4
                loadlcardiocore()
            Case Else
                MsgBox("Light workout error")
        End Select
    End Sub
    Public Sub selectheavyworkout()
        Randomize()
        Dim heavychoice As Integer = Math.Ceiling(Rnd() * 4)
        Select Case True
            Case heavychoice = 1
                loadhbackbi()
            Case heavychoice = 2
                loadhchesttri()
            Case heavychoice = 3
                loadhlegsshoulder()
            Case heavychoice = 4
                loadhcardiocore()
            Case Else
                MsgBox("Heavy workout error")
        End Select
    End Sub
    'clear workouts
    Public Sub clearobjectsL()
        lwo1 = Nothing
        lwo2 = Nothing
        lwo3 = Nothing
        lwo4 = Nothing
        lwo5 = Nothing
        lwo6 = Nothing
    End Sub
    Public Sub clearobjectsH()
        hwo1 = Nothing
        hwo2 = Nothing
        hwo3 = Nothing
        hwo4 = Nothing
        hwo5 = Nothing
        hwo6 = Nothing
        hwo7 = Nothing
        hwo8 = Nothing
    End Sub
    'load methods
    Public Sub loadlbackbi()
        lwo1 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\backone.jpg")
        lt1 = "Single Arm Row"
        lwo2 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\backtwo.jpg")
        lt2 = "T-Bar Row"
        lwo3 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\backthree.jpg")
        lt3 = "Deadlift"
        lwo4 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\bione.jpg")
        lt4 = "Preacher Curl"
        lwo5 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\bitwo.jpg")
        lt5 = "Overhead Cable Curl"
        lwo6 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\bithree.jpg")
        lt6 = "Dumbbell Cable Curl"
    End Sub
    Public Sub loadlchesttri()
        lwo1 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\chestone.jpg")
        lt1 = "Incline Bench"
        lwo2 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\chesttwo.jpg")
        lt2 = "Dumbbell Fly"
        lwo3 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\chestthree.jpg")
        lt3 = "Dumbbell Fly"
        lwo4 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\trione.jpg")
        lt4 = "Tricep Extension"
        lwo5 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\tritwo.jpg")
        lt5 = "Dip"
        lwo6 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\trithree.jpg")
        lt6 = "Skullcrusher2"
    End Sub
    Public Sub loadllegsshoulder()
        lwo1 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\legone.jpg")
        lt1 = "Front Squat"
        lwo2 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\legtwo.jpg")
        lt2 = "Power Squat"
        lwo3 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\legthree.jpg")
        lt3 = "Romanian Deadlift"
        lwo4 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\shoulderone.jpg")
        lt4 = "Fly"
        lwo5 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\shouldertwo.jpg")
        lt5 = "Standing Y Raise"
        lwo6 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\shoulderthree.jpg")
        lt6 = "Bent-Over Y Raise"
    End Sub
    Public Sub loadlcardiocore()
        lwo1 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\cardioone.jpg")
        lt1 = "Bike"
        lwo2 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\cardiotwo.jpg")
        lt2 = "Treadmill"
        lwo3 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\cardiothree.jpg")
        lt3 = "Stairmaster"
        lwo4 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\coreone.jpg")
        lt4 = "Decline Sit-Up"
        lwo5 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\coretwo.jpeg")
        lt5 = "Bridge"
        lwo6 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\corethree.jpg")
        lt6 = "Plank"
    End Sub
    Public Sub loadhbackbi()
        hwo1 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\backone.jpg")
        ht1 = "Single Arm Row"
        hwo2 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\backtwo.jpg")
        ht2 = "T-Bar Row"
        hwo3 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\backthree.jpg")
        ht3 = "Deadlift"
        hwo4 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\backfour.jpg")
        ht4 = "Pull-Ups"
        hwo5 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\bione.jpg")
        ht5 = "Preacher Curl"
        hwo6 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\bitwo.jpg")
        ht6 = "Cable Curl"
        hwo7 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\bithree.jpg")
        ht7 = "Incline Curl"
        hwo8 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\bifour.jpg")
        ht8 = "EZ-Bar Curl"
    End Sub
    Public Sub loadhchesttri()
        hwo1 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\chestone.jpg")
        ht1 = "Incline Bench"
        hwo2 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\chesttwo.jpg")
        ht2 = "Dumbbell Fly"
        hwo3 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\chestthree.jpg")
        ht3 = "Incline Fly"
        hwo4 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\chestfour.jpg")
        ht4 = "Chest Dips"
        hwo5 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\trione.jpg")
        ht5 = "Tricep Extension"
        hwo6 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\tritwo.jpg")
        ht6 = "Dip"
        hwo7 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\trithree.jpg")
        ht7 = "Skullcrusher2"
        hwo8 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\trifour.jpg")
        ht8 = "Skullcrusher"
    End Sub
    Public Sub loadhlegsshoulder()
        hwo1 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\legone.jpg")
        ht1 = "Front Squat"
        hwo2 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\legtwo.jpg")
        ht2 = "Power Squat"
        hwo3 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\legthree.jpg")
        ht3 = "Romanian Deadlift"
        hwo4 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\legfour.jpg")
        ht4 = "Leg Curls"
        hwo5 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\shoulderone.jpg")
        ht5 = "Fly"
        hwo6 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\shouldertwo.jpg")
        ht6 = "Standing Y Raise"
        hwo7 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\shoulderthree.jpg")
        ht7 = "Bent-Over Fly"
        hwo8 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\shoulderfour.jpg")
        ht8 = "Single Arm Raise"
    End Sub
    Public Sub loadhcardiocore()
        hwo1 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\cardioone.jpg")
        ht1 = "Bike"
        hwo2 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\cardiotwo.jpg")
        ht2 = "Treadmill"
        hwo3 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\cardiothree.jpg")
        ht3 = "Stairmaster"
        hwo4 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\cardiofour.jpg")
        ht4 = "Jump Rope"
        hwo5 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\coreone.jpg")
        ht5 = "Decline Sit-Up"
        hwo6 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\coretwo.jpeg")
        ht6 = "Bridge"
        hwo7 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\corethree.jpg")
        ht7 = "Plank"
        hwo8 = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Workouts" & "\corefour.jpg")
        ht8 = "Side Crunch"
    End Sub
End Module
