﻿'Credit: Peter Iacona (50%), Ian Teal (50%)
Public Class frmAdvOpt
    'load event
    Private Sub frmAdvOpt_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.BackgroundImage = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Backgrounds" & "\purple_bg.png")
        If diet_none = True Then
            radNone.Checked = True
        Else
            radNone.Checked = False
        End If
        If diet_veg = True Then
            radVegetarian.Checked = True
        Else
            radVegetarian.Checked = False
        End If
        If al_eggs = True Then
            chkEggs.Checked = True
        Else
            chkEggs.Checked = False
        End If
        If al_nuts = True Then
            chkPeanut.Checked = True
        Else
            chkPeanut.Checked = False
        End If
    End Sub
    'button clicks
    Private Sub btnBack_advop_Click(sender As Object, e As EventArgs) Handles btnBack_advop.Click
        Me.Close()
    End Sub
    Private Sub btnDeleteProfile_Click(sender As Object, e As EventArgs) Handles btnDeleteProfile.Click
        Dim boxChoice As Integer = MessageBox.Show("Are you sure?", "Delete Profile", MessageBoxButtons.YesNo)
        If boxChoice = DialogResult.Yes Then
            My.Computer.FileSystem.DeleteFile(loginName)
            MessageBox.Show("Profile Deleted")
            Application.Restart()
        End If
    End Sub
    'diet changed (modifies variables from Module Meals)
    Private Sub radNone_CheckedChanged(sender As Object, e As EventArgs) Handles radNone.CheckedChanged
        If radNone.Checked = True Then
            diet_none = True
        Else
            diet_none = False
        End If
    End Sub
    Private Sub radVegetarian_CheckedChanged(sender As Object, e As EventArgs) Handles radVegetarian.CheckedChanged
        If radVegetarian.Checked = True Then
            diet_veg = True
        Else
            diet_veg = False
        End If
    End Sub
    Private Sub chkPeanut_CheckedChanged(sender As Object, e As EventArgs) Handles chkPeanut.CheckedChanged
        If chkPeanut.Checked = True Then
            al_nuts = True
        Else
            al_nuts = False
        End If
    End Sub
    Private Sub chkEggs_CheckedChanged(sender As Object, e As EventArgs) Handles chkEggs.CheckedChanged
        If chkEggs.Checked = True Then
            al_eggs = True
        Else
            al_eggs = False
        End If
    End Sub
End Class
