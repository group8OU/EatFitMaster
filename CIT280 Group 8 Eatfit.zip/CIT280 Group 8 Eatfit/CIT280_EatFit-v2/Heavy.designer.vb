﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmHeavy
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtH4 = New System.Windows.Forms.TextBox()
        Me.txtH3 = New System.Windows.Forms.TextBox()
        Me.txtH2 = New System.Windows.Forms.TextBox()
        Me.txtH1 = New System.Windows.Forms.TextBox()
        Me.pbH4 = New System.Windows.Forms.PictureBox()
        Me.pbH3 = New System.Windows.Forms.PictureBox()
        Me.pbH2 = New System.Windows.Forms.PictureBox()
        Me.pbH1 = New System.Windows.Forms.PictureBox()
        Me.txtH8 = New System.Windows.Forms.TextBox()
        Me.txtH7 = New System.Windows.Forms.TextBox()
        Me.txtH6 = New System.Windows.Forms.TextBox()
        Me.txtH5 = New System.Windows.Forms.TextBox()
        Me.pbH8 = New System.Windows.Forms.PictureBox()
        Me.pbH7 = New System.Windows.Forms.PictureBox()
        Me.pbH6 = New System.Windows.Forms.PictureBox()
        Me.pbH5 = New System.Windows.Forms.PictureBox()
        Me.lblfrm = New System.Windows.Forms.Label()
        Me.btnBack_advop = New System.Windows.Forms.Button()
        Me.btnrefresh = New System.Windows.Forms.Button()
        CType(Me.pbH4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbH3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbH2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbH1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbH8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbH7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbH6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbH5, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'txtH4
        '
        Me.txtH4.Location = New System.Drawing.Point(335, 158)
        Me.txtH4.Name = "txtH4"
        Me.txtH4.ReadOnly = True
        Me.txtH4.Size = New System.Drawing.Size(100, 20)
        Me.txtH4.TabIndex = 35
        Me.txtH4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtH3
        '
        Me.txtH3.Location = New System.Drawing.Point(229, 158)
        Me.txtH3.Name = "txtH3"
        Me.txtH3.ReadOnly = True
        Me.txtH3.Size = New System.Drawing.Size(100, 20)
        Me.txtH3.TabIndex = 34
        Me.txtH3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtH2
        '
        Me.txtH2.Location = New System.Drawing.Point(123, 158)
        Me.txtH2.Name = "txtH2"
        Me.txtH2.ReadOnly = True
        Me.txtH2.Size = New System.Drawing.Size(100, 20)
        Me.txtH2.TabIndex = 33
        Me.txtH2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtH1
        '
        Me.txtH1.Location = New System.Drawing.Point(17, 158)
        Me.txtH1.Name = "txtH1"
        Me.txtH1.ReadOnly = True
        Me.txtH1.Size = New System.Drawing.Size(100, 20)
        Me.txtH1.TabIndex = 32
        Me.txtH1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'pbH4
        '
        Me.pbH4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pbH4.Location = New System.Drawing.Point(335, 52)
        Me.pbH4.Name = "pbH4"
        Me.pbH4.Size = New System.Drawing.Size(100, 100)
        Me.pbH4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbH4.TabIndex = 31
        Me.pbH4.TabStop = False
        '
        'pbH3
        '
        Me.pbH3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pbH3.Location = New System.Drawing.Point(229, 52)
        Me.pbH3.Name = "pbH3"
        Me.pbH3.Size = New System.Drawing.Size(100, 100)
        Me.pbH3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbH3.TabIndex = 30
        Me.pbH3.TabStop = False
        '
        'pbH2
        '
        Me.pbH2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pbH2.Location = New System.Drawing.Point(123, 52)
        Me.pbH2.Name = "pbH2"
        Me.pbH2.Size = New System.Drawing.Size(100, 100)
        Me.pbH2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbH2.TabIndex = 29
        Me.pbH2.TabStop = False
        '
        'pbH1
        '
        Me.pbH1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pbH1.Location = New System.Drawing.Point(17, 52)
        Me.pbH1.Name = "pbH1"
        Me.pbH1.Size = New System.Drawing.Size(100, 100)
        Me.pbH1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbH1.TabIndex = 28
        Me.pbH1.TabStop = False
        '
        'txtH8
        '
        Me.txtH8.Location = New System.Drawing.Point(335, 302)
        Me.txtH8.Name = "txtH8"
        Me.txtH8.ReadOnly = True
        Me.txtH8.Size = New System.Drawing.Size(100, 20)
        Me.txtH8.TabIndex = 43
        Me.txtH8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtH7
        '
        Me.txtH7.Location = New System.Drawing.Point(229, 302)
        Me.txtH7.Name = "txtH7"
        Me.txtH7.ReadOnly = True
        Me.txtH7.Size = New System.Drawing.Size(100, 20)
        Me.txtH7.TabIndex = 42
        Me.txtH7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtH6
        '
        Me.txtH6.Location = New System.Drawing.Point(123, 302)
        Me.txtH6.Name = "txtH6"
        Me.txtH6.ReadOnly = True
        Me.txtH6.Size = New System.Drawing.Size(100, 20)
        Me.txtH6.TabIndex = 41
        Me.txtH6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtH5
        '
        Me.txtH5.Location = New System.Drawing.Point(17, 302)
        Me.txtH5.Name = "txtH5"
        Me.txtH5.ReadOnly = True
        Me.txtH5.Size = New System.Drawing.Size(100, 20)
        Me.txtH5.TabIndex = 40
        Me.txtH5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'pbH8
        '
        Me.pbH8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pbH8.Location = New System.Drawing.Point(335, 196)
        Me.pbH8.Name = "pbH8"
        Me.pbH8.Size = New System.Drawing.Size(100, 100)
        Me.pbH8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbH8.TabIndex = 39
        Me.pbH8.TabStop = False
        '
        'pbH7
        '
        Me.pbH7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pbH7.Location = New System.Drawing.Point(229, 196)
        Me.pbH7.Name = "pbH7"
        Me.pbH7.Size = New System.Drawing.Size(100, 100)
        Me.pbH7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbH7.TabIndex = 38
        Me.pbH7.TabStop = False
        '
        'pbH6
        '
        Me.pbH6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pbH6.Location = New System.Drawing.Point(123, 196)
        Me.pbH6.Name = "pbH6"
        Me.pbH6.Size = New System.Drawing.Size(100, 100)
        Me.pbH6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbH6.TabIndex = 37
        Me.pbH6.TabStop = False
        '
        'pbH5
        '
        Me.pbH5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pbH5.Location = New System.Drawing.Point(17, 196)
        Me.pbH5.Name = "pbH5"
        Me.pbH5.Size = New System.Drawing.Size(100, 100)
        Me.pbH5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbH5.TabIndex = 36
        Me.pbH5.TabStop = False
        '
        'lblfrm
        '
        Me.lblfrm.AutoSize = True
        Me.lblfrm.BackColor = System.Drawing.Color.Transparent
        Me.lblfrm.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblfrm.ForeColor = System.Drawing.Color.White
        Me.lblfrm.Location = New System.Drawing.Point(12, 9)
        Me.lblfrm.Name = "lblfrm"
        Me.lblfrm.Size = New System.Drawing.Size(187, 29)
        Me.lblfrm.TabIndex = 47
        Me.lblfrm.Text = "Heavy Workout"
        '
        'btnBack_advop
        '
        Me.btnBack_advop.BackColor = System.Drawing.Color.Crimson
        Me.btnBack_advop.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnBack_advop.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBack_advop.ForeColor = System.Drawing.SystemColors.Control
        Me.btnBack_advop.Location = New System.Drawing.Point(409, 9)
        Me.btnBack_advop.Name = "btnBack_advop"
        Me.btnBack_advop.Size = New System.Drawing.Size(25, 25)
        Me.btnBack_advop.TabIndex = 46
        Me.btnBack_advop.Text = "X"
        Me.btnBack_advop.UseVisualStyleBackColor = False
        '
        'btnrefresh
        '
        Me.btnrefresh.BackColor = System.Drawing.Color.RoyalBlue
        Me.btnrefresh.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.btnrefresh.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnrefresh.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnrefresh.ForeColor = System.Drawing.Color.White
        Me.btnrefresh.Location = New System.Drawing.Point(378, 9)
        Me.btnrefresh.Name = "btnrefresh"
        Me.btnrefresh.Size = New System.Drawing.Size(25, 25)
        Me.btnrefresh.TabIndex = 45
        Me.btnrefresh.Text = "!"
        Me.btnrefresh.UseVisualStyleBackColor = False
        '
        'frmHeavy
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.IndianRed
        Me.ClientSize = New System.Drawing.Size(449, 338)
        Me.ControlBox = False
        Me.Controls.Add(Me.lblfrm)
        Me.Controls.Add(Me.btnBack_advop)
        Me.Controls.Add(Me.btnrefresh)
        Me.Controls.Add(Me.txtH8)
        Me.Controls.Add(Me.txtH7)
        Me.Controls.Add(Me.txtH6)
        Me.Controls.Add(Me.txtH5)
        Me.Controls.Add(Me.pbH8)
        Me.Controls.Add(Me.pbH7)
        Me.Controls.Add(Me.pbH6)
        Me.Controls.Add(Me.pbH5)
        Me.Controls.Add(Me.txtH4)
        Me.Controls.Add(Me.txtH3)
        Me.Controls.Add(Me.txtH2)
        Me.Controls.Add(Me.txtH1)
        Me.Controls.Add(Me.pbH4)
        Me.Controls.Add(Me.pbH3)
        Me.Controls.Add(Me.pbH2)
        Me.Controls.Add(Me.pbH1)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmHeavy"
        Me.ShowIcon = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Heavy Workout"
        CType(Me.pbH4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbH3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbH2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbH1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbH8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbH7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbH6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbH5, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Private WithEvents txtH4 As TextBox
    Private WithEvents txtH3 As TextBox
    Private WithEvents txtH2 As TextBox
    Private WithEvents txtH1 As TextBox
    Private WithEvents pbH4 As PictureBox
    Private WithEvents pbH3 As PictureBox
    Private WithEvents pbH2 As PictureBox
    Private WithEvents pbH1 As PictureBox
    Private WithEvents txtH8 As TextBox
    Private WithEvents txtH7 As TextBox
    Private WithEvents txtH6 As TextBox
    Private WithEvents txtH5 As TextBox
    Private WithEvents pbH8 As PictureBox
    Private WithEvents pbH7 As PictureBox
    Private WithEvents pbH6 As PictureBox
    Private WithEvents pbH5 As PictureBox
    Friend WithEvents lblfrm As System.Windows.Forms.Label
    Friend WithEvents btnBack_advop As System.Windows.Forms.Button
    Friend WithEvents btnrefresh As System.Windows.Forms.Button
End Class
