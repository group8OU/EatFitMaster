﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmLight
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtL6 = New System.Windows.Forms.TextBox()
        Me.txtL5 = New System.Windows.Forms.TextBox()
        Me.txtL3 = New System.Windows.Forms.TextBox()
        Me.txtL2 = New System.Windows.Forms.TextBox()
        Me.txtL1 = New System.Windows.Forms.TextBox()
        Me.pbL5 = New System.Windows.Forms.PictureBox()
        Me.pbL4 = New System.Windows.Forms.PictureBox()
        Me.pbL1 = New System.Windows.Forms.PictureBox()
        Me.pbL2 = New System.Windows.Forms.PictureBox()
        Me.pbL3 = New System.Windows.Forms.PictureBox()
        Me.pbL6 = New System.Windows.Forms.PictureBox()
        Me.txtL4 = New System.Windows.Forms.TextBox()
        Me.lbllw = New System.Windows.Forms.Label()
        Me.btnBack_advop = New System.Windows.Forms.Button()
        Me.btnrefresh = New System.Windows.Forms.Button()
        CType(Me.pbL5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbL4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbL1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbL2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbL3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbL6, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'txtL6
        '
        Me.txtL6.BackColor = System.Drawing.Color.White
        Me.txtL6.Location = New System.Drawing.Point(229, 301)
        Me.txtL6.Name = "txtL6"
        Me.txtL6.ReadOnly = True
        Me.txtL6.Size = New System.Drawing.Size(100, 20)
        Me.txtL6.TabIndex = 39
        Me.txtL6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtL5
        '
        Me.txtL5.BackColor = System.Drawing.Color.White
        Me.txtL5.Location = New System.Drawing.Point(123, 301)
        Me.txtL5.Name = "txtL5"
        Me.txtL5.ReadOnly = True
        Me.txtL5.Size = New System.Drawing.Size(100, 20)
        Me.txtL5.TabIndex = 38
        Me.txtL5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtL3
        '
        Me.txtL3.BackColor = System.Drawing.Color.White
        Me.txtL3.Location = New System.Drawing.Point(229, 156)
        Me.txtL3.Name = "txtL3"
        Me.txtL3.ReadOnly = True
        Me.txtL3.Size = New System.Drawing.Size(100, 20)
        Me.txtL3.TabIndex = 37
        Me.txtL3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtL2
        '
        Me.txtL2.BackColor = System.Drawing.Color.White
        Me.txtL2.Location = New System.Drawing.Point(123, 156)
        Me.txtL2.Name = "txtL2"
        Me.txtL2.ReadOnly = True
        Me.txtL2.Size = New System.Drawing.Size(100, 20)
        Me.txtL2.TabIndex = 36
        Me.txtL2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtL1
        '
        Me.txtL1.BackColor = System.Drawing.Color.White
        Me.txtL1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtL1.Location = New System.Drawing.Point(17, 156)
        Me.txtL1.Name = "txtL1"
        Me.txtL1.ReadOnly = True
        Me.txtL1.Size = New System.Drawing.Size(100, 20)
        Me.txtL1.TabIndex = 35
        Me.txtL1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'pbL5
        '
        Me.pbL5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pbL5.Location = New System.Drawing.Point(123, 195)
        Me.pbL5.Name = "pbL5"
        Me.pbL5.Size = New System.Drawing.Size(100, 100)
        Me.pbL5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbL5.TabIndex = 34
        Me.pbL5.TabStop = False
        '
        'pbL4
        '
        Me.pbL4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pbL4.Location = New System.Drawing.Point(17, 195)
        Me.pbL4.Name = "pbL4"
        Me.pbL4.Size = New System.Drawing.Size(100, 100)
        Me.pbL4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbL4.TabIndex = 33
        Me.pbL4.TabStop = False
        '
        'pbL1
        '
        Me.pbL1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pbL1.Location = New System.Drawing.Point(17, 50)
        Me.pbL1.Name = "pbL1"
        Me.pbL1.Size = New System.Drawing.Size(100, 100)
        Me.pbL1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbL1.TabIndex = 30
        Me.pbL1.TabStop = False
        '
        'pbL2
        '
        Me.pbL2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pbL2.Location = New System.Drawing.Point(123, 50)
        Me.pbL2.Name = "pbL2"
        Me.pbL2.Size = New System.Drawing.Size(100, 100)
        Me.pbL2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbL2.TabIndex = 31
        Me.pbL2.TabStop = False
        '
        'pbL3
        '
        Me.pbL3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pbL3.Location = New System.Drawing.Point(229, 50)
        Me.pbL3.Name = "pbL3"
        Me.pbL3.Size = New System.Drawing.Size(100, 100)
        Me.pbL3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbL3.TabIndex = 32
        Me.pbL3.TabStop = False
        '
        'pbL6
        '
        Me.pbL6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pbL6.Location = New System.Drawing.Point(229, 195)
        Me.pbL6.Name = "pbL6"
        Me.pbL6.Size = New System.Drawing.Size(100, 100)
        Me.pbL6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbL6.TabIndex = 40
        Me.pbL6.TabStop = False
        '
        'txtL4
        '
        Me.txtL4.BackColor = System.Drawing.Color.White
        Me.txtL4.Location = New System.Drawing.Point(17, 301)
        Me.txtL4.Name = "txtL4"
        Me.txtL4.ReadOnly = True
        Me.txtL4.Size = New System.Drawing.Size(100, 20)
        Me.txtL4.TabIndex = 41
        Me.txtL4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lbllw
        '
        Me.lbllw.AutoSize = True
        Me.lbllw.BackColor = System.Drawing.Color.Transparent
        Me.lbllw.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbllw.ForeColor = System.Drawing.Color.White
        Me.lbllw.Location = New System.Drawing.Point(12, 9)
        Me.lbllw.Name = "lbllw"
        Me.lbllw.Size = New System.Drawing.Size(173, 29)
        Me.lbllw.TabIndex = 44
        Me.lbllw.Text = "Light Workout"
        '
        'btnBack_advop
        '
        Me.btnBack_advop.BackColor = System.Drawing.Color.Crimson
        Me.btnBack_advop.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnBack_advop.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBack_advop.ForeColor = System.Drawing.SystemColors.Control
        Me.btnBack_advop.Location = New System.Drawing.Point(304, 9)
        Me.btnBack_advop.Name = "btnBack_advop"
        Me.btnBack_advop.Size = New System.Drawing.Size(25, 25)
        Me.btnBack_advop.TabIndex = 43
        Me.btnBack_advop.Text = "X"
        Me.btnBack_advop.UseVisualStyleBackColor = False
        '
        'btnrefresh
        '
        Me.btnrefresh.BackColor = System.Drawing.Color.RoyalBlue
        Me.btnrefresh.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.btnrefresh.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnrefresh.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnrefresh.ForeColor = System.Drawing.Color.White
        Me.btnrefresh.Location = New System.Drawing.Point(273, 9)
        Me.btnrefresh.Name = "btnrefresh"
        Me.btnrefresh.Size = New System.Drawing.Size(25, 25)
        Me.btnrefresh.TabIndex = 42
        Me.btnrefresh.Text = "!"
        Me.btnrefresh.UseVisualStyleBackColor = False
        '
        'frmLight
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.DarkOrange
        Me.ClientSize = New System.Drawing.Size(345, 339)
        Me.ControlBox = False
        Me.Controls.Add(Me.lbllw)
        Me.Controls.Add(Me.btnBack_advop)
        Me.Controls.Add(Me.btnrefresh)
        Me.Controls.Add(Me.txtL4)
        Me.Controls.Add(Me.pbL6)
        Me.Controls.Add(Me.txtL6)
        Me.Controls.Add(Me.txtL5)
        Me.Controls.Add(Me.txtL3)
        Me.Controls.Add(Me.txtL2)
        Me.Controls.Add(Me.txtL1)
        Me.Controls.Add(Me.pbL5)
        Me.Controls.Add(Me.pbL4)
        Me.Controls.Add(Me.pbL3)
        Me.Controls.Add(Me.pbL2)
        Me.Controls.Add(Me.pbL1)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmLight"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Light Workout"
        CType(Me.pbL5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbL4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbL1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbL2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbL3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbL6, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Private WithEvents txtL6 As TextBox
    Private WithEvents txtL5 As TextBox
    Private WithEvents txtL3 As TextBox
    Private WithEvents txtL2 As TextBox
    Private WithEvents txtL1 As TextBox
    Private WithEvents pbL5 As PictureBox
    Private WithEvents pbL4 As PictureBox
    Private WithEvents pbL1 As PictureBox
    Private WithEvents pbL2 As PictureBox
    Private WithEvents pbL3 As PictureBox
    Private WithEvents pbL6 As PictureBox
    Private WithEvents txtL4 As TextBox
    Friend WithEvents lbllw As System.Windows.Forms.Label
    Friend WithEvents btnBack_advop As System.Windows.Forms.Button
    Friend WithEvents btnrefresh As System.Windows.Forms.Button
End Class
