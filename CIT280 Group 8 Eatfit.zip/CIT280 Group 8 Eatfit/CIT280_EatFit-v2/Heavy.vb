﻿Public Class frmHeavy
    Private Sub frmHeavy_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.BackgroundImage = System.Drawing.Bitmap.FromFile(My.Application.Info.DirectoryPath & "\Backgrounds" & "\silver_bg.png")
        startheavy()
    End Sub
    Private Sub getworkouts()
        pbH1.Image = hwo1
        pbH2.Image = hwo2
        pbH3.Image = hwo3
        pbH4.Image = hwo4
        pbH5.Image = hwo5
        pbH6.Image = hwo6
        pbH7.Image = hwo7
        pbH8.Image = hwo8
        txtH1.Text = ht1
        txtH2.Text = ht2
        txtH3.Text = ht3
        txtH4.Text = ht4
        txtH5.Text = ht5
        txtH6.Text = ht6
        txtH7.Text = ht7
        txtH8.Text = ht8
    End Sub
    Private Sub frmLight_FormClosed(sender As Object, e As FormClosedEventArgs) Handles Me.FormClosed
        clearobjectsH()
    End Sub
    Private Sub btnrefresh_Click(sender As Object, e As EventArgs) Handles btnrefresh.Click
        startheavy()
    End Sub
    Public Sub startheavy()
        selectheavyworkout()
        getworkouts()
    End Sub
    Private Sub btnBack_advop_Click(sender As Object, e As EventArgs) Handles btnBack_advop.Click
        Me.Close()
    End Sub
End Class