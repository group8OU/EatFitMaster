﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmBreakfast
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtBDrink = New System.Windows.Forms.TextBox()
        Me.txtBFruit = New System.Windows.Forms.TextBox()
        Me.txtBGrain = New System.Windows.Forms.TextBox()
        Me.txtBProtein = New System.Windows.Forms.TextBox()
        Me.pbBDrink = New System.Windows.Forms.PictureBox()
        Me.pbBFruit = New System.Windows.Forms.PictureBox()
        Me.pbBGrain = New System.Windows.Forms.PictureBox()
        Me.pbBProtein = New System.Windows.Forms.PictureBox()
        Me.lblfrm = New System.Windows.Forms.Label()
        Me.btnBack_advop = New System.Windows.Forms.Button()
        Me.btnrefresh = New System.Windows.Forms.Button()
        CType(Me.pbBDrink, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbBFruit, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbBGrain, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbBProtein, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'txtBDrink
        '
        Me.txtBDrink.Location = New System.Drawing.Point(335, 160)
        Me.txtBDrink.Name = "txtBDrink"
        Me.txtBDrink.ReadOnly = True
        Me.txtBDrink.Size = New System.Drawing.Size(100, 20)
        Me.txtBDrink.TabIndex = 27
        Me.txtBDrink.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtBFruit
        '
        Me.txtBFruit.Location = New System.Drawing.Point(229, 160)
        Me.txtBFruit.Name = "txtBFruit"
        Me.txtBFruit.ReadOnly = True
        Me.txtBFruit.Size = New System.Drawing.Size(100, 20)
        Me.txtBFruit.TabIndex = 26
        Me.txtBFruit.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtBGrain
        '
        Me.txtBGrain.Location = New System.Drawing.Point(123, 160)
        Me.txtBGrain.Name = "txtBGrain"
        Me.txtBGrain.ReadOnly = True
        Me.txtBGrain.Size = New System.Drawing.Size(100, 20)
        Me.txtBGrain.TabIndex = 25
        Me.txtBGrain.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtBProtein
        '
        Me.txtBProtein.Location = New System.Drawing.Point(17, 160)
        Me.txtBProtein.Name = "txtBProtein"
        Me.txtBProtein.ReadOnly = True
        Me.txtBProtein.Size = New System.Drawing.Size(100, 20)
        Me.txtBProtein.TabIndex = 24
        Me.txtBProtein.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'pbBDrink
        '
        Me.pbBDrink.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pbBDrink.Location = New System.Drawing.Point(335, 41)
        Me.pbBDrink.Name = "pbBDrink"
        Me.pbBDrink.Size = New System.Drawing.Size(100, 100)
        Me.pbBDrink.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbBDrink.TabIndex = 23
        Me.pbBDrink.TabStop = False
        '
        'pbBFruit
        '
        Me.pbBFruit.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pbBFruit.Location = New System.Drawing.Point(229, 41)
        Me.pbBFruit.Name = "pbBFruit"
        Me.pbBFruit.Size = New System.Drawing.Size(100, 100)
        Me.pbBFruit.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbBFruit.TabIndex = 22
        Me.pbBFruit.TabStop = False
        '
        'pbBGrain
        '
        Me.pbBGrain.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pbBGrain.Location = New System.Drawing.Point(123, 41)
        Me.pbBGrain.Name = "pbBGrain"
        Me.pbBGrain.Size = New System.Drawing.Size(100, 100)
        Me.pbBGrain.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbBGrain.TabIndex = 21
        Me.pbBGrain.TabStop = False
        '
        'pbBProtein
        '
        Me.pbBProtein.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pbBProtein.Location = New System.Drawing.Point(17, 41)
        Me.pbBProtein.Name = "pbBProtein"
        Me.pbBProtein.Size = New System.Drawing.Size(100, 100)
        Me.pbBProtein.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbBProtein.TabIndex = 20
        Me.pbBProtein.TabStop = False
        '
        'lblfrm
        '
        Me.lblfrm.AutoSize = True
        Me.lblfrm.BackColor = System.Drawing.Color.Transparent
        Me.lblfrm.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblfrm.ForeColor = System.Drawing.Color.White
        Me.lblfrm.Location = New System.Drawing.Point(12, 9)
        Me.lblfrm.Name = "lblfrm"
        Me.lblfrm.Size = New System.Drawing.Size(122, 29)
        Me.lblfrm.TabIndex = 53
        Me.lblfrm.Text = "Breakfast"
        '
        'btnBack_advop
        '
        Me.btnBack_advop.BackColor = System.Drawing.Color.Crimson
        Me.btnBack_advop.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnBack_advop.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBack_advop.ForeColor = System.Drawing.SystemColors.Control
        Me.btnBack_advop.Location = New System.Drawing.Point(409, 9)
        Me.btnBack_advop.Name = "btnBack_advop"
        Me.btnBack_advop.Size = New System.Drawing.Size(25, 25)
        Me.btnBack_advop.TabIndex = 52
        Me.btnBack_advop.Text = "X"
        Me.btnBack_advop.UseVisualStyleBackColor = False
        '
        'btnrefresh
        '
        Me.btnrefresh.BackColor = System.Drawing.Color.RoyalBlue
        Me.btnrefresh.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.btnrefresh.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnrefresh.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnrefresh.ForeColor = System.Drawing.Color.White
        Me.btnrefresh.Location = New System.Drawing.Point(378, 9)
        Me.btnrefresh.Name = "btnrefresh"
        Me.btnrefresh.Size = New System.Drawing.Size(25, 25)
        Me.btnrefresh.TabIndex = 51
        Me.btnrefresh.Text = "!"
        Me.btnrefresh.UseVisualStyleBackColor = False
        '
        'frmBreakfast
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.OrangeRed
        Me.ClientSize = New System.Drawing.Size(447, 195)
        Me.ControlBox = False
        Me.Controls.Add(Me.lblfrm)
        Me.Controls.Add(Me.btnBack_advop)
        Me.Controls.Add(Me.btnrefresh)
        Me.Controls.Add(Me.txtBDrink)
        Me.Controls.Add(Me.txtBFruit)
        Me.Controls.Add(Me.txtBGrain)
        Me.Controls.Add(Me.txtBProtein)
        Me.Controls.Add(Me.pbBDrink)
        Me.Controls.Add(Me.pbBFruit)
        Me.Controls.Add(Me.pbBGrain)
        Me.Controls.Add(Me.pbBProtein)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmBreakfast"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Breakfast"
        CType(Me.pbBDrink, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbBFruit, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbBGrain, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbBProtein, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Private WithEvents txtBDrink As TextBox
    Private WithEvents txtBFruit As TextBox
    Private WithEvents txtBGrain As TextBox
    Private WithEvents txtBProtein As TextBox
    Private WithEvents pbBDrink As PictureBox
    Private WithEvents pbBFruit As PictureBox
    Private WithEvents pbBGrain As PictureBox
    Private WithEvents pbBProtein As PictureBox
    Friend WithEvents lblfrm As System.Windows.Forms.Label
    Friend WithEvents btnBack_advop As System.Windows.Forms.Button
    Friend WithEvents btnrefresh As System.Windows.Forms.Button
End Class
