﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmLight
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtL6 = New System.Windows.Forms.TextBox()
        Me.txtL5 = New System.Windows.Forms.TextBox()
        Me.txtL3 = New System.Windows.Forms.TextBox()
        Me.txtL2 = New System.Windows.Forms.TextBox()
        Me.txtL1 = New System.Windows.Forms.TextBox()
        Me.pbL7 = New System.Windows.Forms.PictureBox()
        Me.pbL5 = New System.Windows.Forms.PictureBox()
        Me.pbL4 = New System.Windows.Forms.PictureBox()
        Me.pbL2 = New System.Windows.Forms.PictureBox()
        Me.pbL1 = New System.Windows.Forms.PictureBox()
        CType(Me.pbL7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbL5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbL4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbL2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbL1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'txtL6
        '
        Me.txtL6.BackColor = System.Drawing.Color.NavajoWhite
        Me.txtL6.Location = New System.Drawing.Point(454, 115)
        Me.txtL6.Name = "txtL6"
        Me.txtL6.Size = New System.Drawing.Size(100, 20)
        Me.txtL6.TabIndex = 39
        '
        'txtL5
        '
        Me.txtL5.BackColor = System.Drawing.Color.NavajoWhite
        Me.txtL5.Location = New System.Drawing.Point(348, 115)
        Me.txtL5.Name = "txtL5"
        Me.txtL5.Size = New System.Drawing.Size(100, 20)
        Me.txtL5.TabIndex = 38
        '
        'txtL3
        '
        Me.txtL3.BackColor = System.Drawing.Color.NavajoWhite
        Me.txtL3.Location = New System.Drawing.Point(242, 115)
        Me.txtL3.Name = "txtL3"
        Me.txtL3.Size = New System.Drawing.Size(100, 20)
        Me.txtL3.TabIndex = 37
        '
        'txtL2
        '
        Me.txtL2.BackColor = System.Drawing.Color.NavajoWhite
        Me.txtL2.Location = New System.Drawing.Point(136, 115)
        Me.txtL2.Name = "txtL2"
        Me.txtL2.Size = New System.Drawing.Size(100, 20)
        Me.txtL2.TabIndex = 36
        '
        'txtL1
        '
        Me.txtL1.BackColor = System.Drawing.Color.NavajoWhite
        Me.txtL1.Location = New System.Drawing.Point(30, 115)
        Me.txtL1.Name = "txtL1"
        Me.txtL1.Size = New System.Drawing.Size(100, 20)
        Me.txtL1.TabIndex = 35
        '
        'pbL7
        '
        Me.pbL7.Location = New System.Drawing.Point(454, 31)
        Me.pbL7.Name = "pbL7"
        Me.pbL7.Size = New System.Drawing.Size(100, 78)
        Me.pbL7.TabIndex = 34
        Me.pbL7.TabStop = False
        '
        'pbL5
        '
        Me.pbL5.Location = New System.Drawing.Point(348, 31)
        Me.pbL5.Name = "pbL5"
        Me.pbL5.Size = New System.Drawing.Size(100, 78)
        Me.pbL5.TabIndex = 33
        Me.pbL5.TabStop = False
        '
        'pbL4
        '
        Me.pbL4.Location = New System.Drawing.Point(242, 31)
        Me.pbL4.Name = "pbL4"
        Me.pbL4.Size = New System.Drawing.Size(100, 78)
        Me.pbL4.TabIndex = 32
        Me.pbL4.TabStop = False
        '
        'pbL2
        '
        Me.pbL2.Location = New System.Drawing.Point(136, 31)
        Me.pbL2.Name = "pbL2"
        Me.pbL2.Size = New System.Drawing.Size(100, 78)
        Me.pbL2.TabIndex = 31
        Me.pbL2.TabStop = False
        '
        'pbL1
        '
        Me.pbL1.Location = New System.Drawing.Point(30, 31)
        Me.pbL1.Name = "pbL1"
        Me.pbL1.Size = New System.Drawing.Size(100, 78)
        Me.pbL1.TabIndex = 30
        Me.pbL1.TabStop = False
        '
        'frmLight
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.DarkOrange
        Me.ClientSize = New System.Drawing.Size(584, 166)
        Me.Controls.Add(Me.txtL6)
        Me.Controls.Add(Me.txtL5)
        Me.Controls.Add(Me.txtL3)
        Me.Controls.Add(Me.txtL2)
        Me.Controls.Add(Me.txtL1)
        Me.Controls.Add(Me.pbL7)
        Me.Controls.Add(Me.pbL5)
        Me.Controls.Add(Me.pbL4)
        Me.Controls.Add(Me.pbL2)
        Me.Controls.Add(Me.pbL1)
        Me.Name = "frmLight"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Light Workout"
        CType(Me.pbL7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbL5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbL4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbL2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbL1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Private WithEvents txtL6 As TextBox
    Private WithEvents txtL5 As TextBox
    Private WithEvents txtL3 As TextBox
    Private WithEvents txtL2 As TextBox
    Private WithEvents txtL1 As TextBox
    Private WithEvents pbL7 As PictureBox
    Private WithEvents pbL5 As PictureBox
    Private WithEvents pbL4 As PictureBox
    Private WithEvents pbL2 As PictureBox
    Private WithEvents pbL1 As PictureBox
End Class
