﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmDinner
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtDDrink = New System.Windows.Forms.TextBox()
        Me.txtDFruit = New System.Windows.Forms.TextBox()
        Me.txtDGrain = New System.Windows.Forms.TextBox()
        Me.txtDVegetable = New System.Windows.Forms.TextBox()
        Me.txtDProtein = New System.Windows.Forms.TextBox()
        Me.pbDDrink = New System.Windows.Forms.PictureBox()
        Me.pbDFruit = New System.Windows.Forms.PictureBox()
        Me.pbDGrain = New System.Windows.Forms.PictureBox()
        Me.pbDVegetable = New System.Windows.Forms.PictureBox()
        Me.pbDProtein = New System.Windows.Forms.PictureBox()
        CType(Me.pbDDrink, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbDFruit, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbDGrain, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbDVegetable, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbDProtein, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'txtDDrink
        '
        Me.txtDDrink.BackColor = System.Drawing.Color.NavajoWhite
        Me.txtDDrink.Location = New System.Drawing.Point(454, 134)
        Me.txtDDrink.Name = "txtDDrink"
        Me.txtDDrink.ReadOnly = True
        Me.txtDDrink.Size = New System.Drawing.Size(100, 20)
        Me.txtDDrink.TabIndex = 29
        Me.txtDDrink.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtDFruit
        '
        Me.txtDFruit.BackColor = System.Drawing.Color.NavajoWhite
        Me.txtDFruit.Location = New System.Drawing.Point(348, 134)
        Me.txtDFruit.Name = "txtDFruit"
        Me.txtDFruit.ReadOnly = True
        Me.txtDFruit.Size = New System.Drawing.Size(100, 20)
        Me.txtDFruit.TabIndex = 28
        Me.txtDFruit.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtDGrain
        '
        Me.txtDGrain.BackColor = System.Drawing.Color.NavajoWhite
        Me.txtDGrain.Location = New System.Drawing.Point(242, 134)
        Me.txtDGrain.Name = "txtDGrain"
        Me.txtDGrain.ReadOnly = True
        Me.txtDGrain.Size = New System.Drawing.Size(100, 20)
        Me.txtDGrain.TabIndex = 27
        Me.txtDGrain.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtDVegetable
        '
        Me.txtDVegetable.BackColor = System.Drawing.Color.NavajoWhite
        Me.txtDVegetable.Location = New System.Drawing.Point(136, 134)
        Me.txtDVegetable.Name = "txtDVegetable"
        Me.txtDVegetable.ReadOnly = True
        Me.txtDVegetable.Size = New System.Drawing.Size(100, 20)
        Me.txtDVegetable.TabIndex = 26
        Me.txtDVegetable.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtDProtein
        '
        Me.txtDProtein.BackColor = System.Drawing.Color.NavajoWhite
        Me.txtDProtein.Location = New System.Drawing.Point(30, 134)
        Me.txtDProtein.Name = "txtDProtein"
        Me.txtDProtein.ReadOnly = True
        Me.txtDProtein.Size = New System.Drawing.Size(100, 20)
        Me.txtDProtein.TabIndex = 25
        Me.txtDProtein.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'pbDDrink
        '
        Me.pbDDrink.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pbDDrink.Location = New System.Drawing.Point(454, 28)
        Me.pbDDrink.Name = "pbDDrink"
        Me.pbDDrink.Size = New System.Drawing.Size(100, 100)
        Me.pbDDrink.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbDDrink.TabIndex = 24
        Me.pbDDrink.TabStop = False
        '
        'pbDFruit
        '
        Me.pbDFruit.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pbDFruit.Location = New System.Drawing.Point(348, 28)
        Me.pbDFruit.Name = "pbDFruit"
        Me.pbDFruit.Size = New System.Drawing.Size(100, 100)
        Me.pbDFruit.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbDFruit.TabIndex = 23
        Me.pbDFruit.TabStop = False
        '
        'pbDGrain
        '
        Me.pbDGrain.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pbDGrain.Location = New System.Drawing.Point(242, 28)
        Me.pbDGrain.Name = "pbDGrain"
        Me.pbDGrain.Size = New System.Drawing.Size(100, 100)
        Me.pbDGrain.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbDGrain.TabIndex = 22
        Me.pbDGrain.TabStop = False
        '
        'pbDVegetable
        '
        Me.pbDVegetable.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pbDVegetable.Location = New System.Drawing.Point(136, 28)
        Me.pbDVegetable.Name = "pbDVegetable"
        Me.pbDVegetable.Size = New System.Drawing.Size(100, 100)
        Me.pbDVegetable.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbDVegetable.TabIndex = 21
        Me.pbDVegetable.TabStop = False
        '
        'pbDProtein
        '
        Me.pbDProtein.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pbDProtein.Location = New System.Drawing.Point(30, 28)
        Me.pbDProtein.Name = "pbDProtein"
        Me.pbDProtein.Size = New System.Drawing.Size(100, 100)
        Me.pbDProtein.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbDProtein.TabIndex = 20
        Me.pbDProtein.TabStop = False
        '
        'frmDinner
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Wheat
        Me.ClientSize = New System.Drawing.Size(584, 175)
        Me.Controls.Add(Me.txtDDrink)
        Me.Controls.Add(Me.txtDFruit)
        Me.Controls.Add(Me.txtDGrain)
        Me.Controls.Add(Me.txtDVegetable)
        Me.Controls.Add(Me.txtDProtein)
        Me.Controls.Add(Me.pbDDrink)
        Me.Controls.Add(Me.pbDFruit)
        Me.Controls.Add(Me.pbDGrain)
        Me.Controls.Add(Me.pbDVegetable)
        Me.Controls.Add(Me.pbDProtein)
        Me.Name = "frmDinner"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Dinner"
        CType(Me.pbDDrink, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbDFruit, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbDGrain, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbDVegetable, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbDProtein, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Private WithEvents txtDDrink As TextBox
    Private WithEvents txtDFruit As TextBox
    Private WithEvents txtDGrain As TextBox
    Private WithEvents txtDVegetable As TextBox
    Private WithEvents txtDProtein As TextBox
    Private WithEvents pbDDrink As PictureBox
    Private WithEvents pbDFruit As PictureBox
    Private WithEvents pbDGrain As PictureBox
    Private WithEvents pbDVegetable As PictureBox
    Private WithEvents pbDProtein As PictureBox
End Class
