﻿Public Class frmAdvOpt
    Private Sub btnBack_advop_Click(sender As Object, e As EventArgs) Handles btnBack_advop.Click
        Me.Close()
    End Sub

    Private Sub frmAdvOpt_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
